import type { VerticalNavItems } from '@layouts/types'
import dashboard from './dashboard'
// import others from './others'

export default [...dashboard] as VerticalNavItems
