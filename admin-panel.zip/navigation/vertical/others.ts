export default [
  { heading: "Management" },
  {
    title: "User",
    icon: { icon: "ri-list-settings-line" },
    to: "management-user",
  },
  {
    title: "Role",
    icon: { icon: "ri-shield-line" },
    to: "management-role",
  },
];
