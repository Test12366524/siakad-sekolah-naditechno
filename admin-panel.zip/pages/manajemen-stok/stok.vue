<script setup lang="ts">
import { useRuntimeConfig } from "#app"; // Import useRuntimeConfig
import { onMounted, reactive, ref, watch } from "vue";
import { VRow } from "vuetify/lib/components/index.mjs";

const config = useRuntimeConfig();

// State for edit and delete confirmation dialogs
const contentData = ref([]);
const listGudang = ref([]);
const listRak = ref([]);
const selectedGudang = ref(null);
const selectedRak = ref(null);

const search = ref("");

const pagination = reactive({
  page: 1,
  limit: 10,
  itemsPerPage: 10,
  totalPages: 0,
});

let value_page = 1;
const total_item = 0;

// Headers for the table
const headers = [
  { title: "Gudang", key: "gudang", sortable: false },
  { title: "Rak", key: "rak", sortable: false },
  { title: "Produk", key: "product", sortable: false },
  { title: "Saldo Stock", key: "saldo", sortable: false },
  { title: "Actions", key: "actions", sortable: false },
];

// Function to fetch data from the API
const fetchData = async () => {
  useApi("/stok").then(({ data }) => {
    console.log("data", data);
  });
};

const getListGudang = () => {
  useApi("/gudang/all").then(({ data }) => {
    listGudang.value = data;
    console.log("data", data);
  });
};

const getListRak = () => {
  useApi("/rak/all/0").then(({ data }) => {
    listRak.value = data;
    console.log("RAK", data);
  });
};

// Fetch data when the component is mounted
onMounted(async () => {
  getListGudang();
  getListRak();
  fetchData();
});

// Watch pagination or search changes to refetch data
watch(
  () => [pagination.itemsPerPage, search.value],
  () => {
    fetchData();
  }
);

// Pagination functions
const goToNextPage = () => {
  if (pagination.page < pagination.totalPages) {
    value_page += 1;
    pagination.page = value_page;
    fetchData();
  }
};

const goToPreviousPage = () => {
  if (value_page > 1) {
    value_page -= 1;
    pagination.page = value_page;
    fetchData();
  }
};
</script>

<template>
  <VRow>
    <VRow style="margin-block-end: 10px">
      <VCol cols="12" md="12" sm="12">
        <div>
          <VCard class="logistics-card-statistics cursor-pointer">
            <VCardText>
              <VRow>
                <VCol cols="12" sm="3" md="3">
                  <VAutocomplete
                    v-model="selectedGudang"
                    label="Gudang"
                    placeholder="Filter by Gudang"
                    :items="listGudang"
                    item-title="text"
                    item-value="value"
                    required
                  />
                </VCol>
                <VCol cols="12" sm="3" md="3">
                  <VAutocomplete
                    v-model="selectedRak"
                    label="Rak"
                    placeholder="Filter by Rak"
                    :items="listRak"
                    item-title="text"
                    item-value="value"
                    required
                  />
                </VCol>
                <VCol cols="12" offset-md="6" md="6" class="ms-md-auto">
                  <VTextField
                    v-model="search"
                    label="Search"
                    placeholder="Search ..."
                    append-inner-icon="ri-search-line"
                    single-line
                    hide-details
                    dense
                    outlined
                  />
                </VCol>
              </VRow>
            </VCardText>
          </VCard>
        </div>
      </VCol>
    </VRow>
    <!-- Data Table -->
    <VDataTable
      v-model:page="pagination.page"
      :headers="headers"
      :items="contentData"
      :search="search"
      :items-per-page="pagination.itemsPerPage"
      :page-count="pagination.totalPages"
      class="text-no-wrap"
    >
      <template #[`item.actions`]="{ item }">
        <div class="d-flex gap-1">
          <NuxtLink :to="`/manajemen-stok/history?id=${item.id}`">
            <VIcon icon="ri-file-list-3-line" /> History
          </NuxtLink>
        </div>
      </template>

      <!-- Pagination -->
      <template #bottom>
        <VDivider />
        <div class="d-flex justify-end flex-wrap gap-x-6 px-2 py-1">
          <div
            class="d-flex align-center gap-x-2 text-medium-emphasis text-base"
          >
            Total Data: <b>{{ total_item }}</b> - Baris / Halaman:
            <VSelect
              v-model="pagination.itemsPerPage"
              class="per-page-select"
              variant="plain"
              :items="[10, 20, 25, 50, 100]"
            />
          </div>
          <div class="d-flex gap-x-2 align-center me-2">
            <VBtn
              class="flip-in-rtl"
              icon="ri-arrow-left-s-line"
              variant="text"
              density="comfortable"
              color="high-emphasis"
              @click="goToPreviousPage"
            />
            Halaman: <b>{{ value_page }}</b>
            <VBtn
              class="flip-in-rtl"
              icon="ri-arrow-right-s-line"
              density="comfortable"
              variant="text"
              color="high-emphasis"
              @click="goToNextPage"
            />
          </div>
        </div>
      </template>
    </VDataTable>
  </VRow>
</template>

<style lang="scss" scoped>
@use "@core/scss/base/mixins" as mixins;

.logistics-card-statistics {
  border-block-end-style: solid;
  border-block-end-width: 2px;
}
</style>
