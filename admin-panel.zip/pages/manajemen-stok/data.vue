<script setup lang="ts">
const { confirmDialog } = useCommonStore();

const approvalDialog = ref();
const paymentDialog = ref();

const suppliers = ref();
const tokos = ref();
const banks = ref();
const tableRef = ref();

const pagination = reactive({
  page: 1,
  itemsPerPage: 10,
  totalPages: 0,
  totalItem: 0,
});

const params = reactive({ itemsPerPage: 5, limit: 5, page: 1, search: "" });

// Headers for the table
const headers = [
  {
    title: "Tanggal",
    key: "po_date",
    sortable: false,
  },
  {
    title: "Supplier",
    key: "supplier_name",
    sortable: false,
  },
  {
    title: "Bank",
    key: "bank_name",
    sortable: false,
  },
  {
    title: "Total Harga",
    key: "total_price",
    sortable: false,
  },
  {
    title: "Pembayaran",
    key: "payment",
    sortable: false,
  },
  {
    title: "Keterangan",
    key: "description",
    sortable: false,
  },
  {
    title: "Status",
    key: "status_desc",
    sortable: false,
  },
  {
    title: "Actions",
    key: "actions",
    sortable: false,
  },
];

const supplierList = ref([]);
const bankList = ref([]);

const selectedSupplier = ref(null);
const selectedBank = ref(null);
const selectedBankId = ref(null);
const selectedSupplierId = ref(null);
const selectedRange = ref(null);
const contentData = ref([]);

const form = ref({
  kategori_pemasukan_id: undefined,
  marketplace_id: undefined,
  toko_id: undefined,
  bank_id: undefined,
  nominal: "",
  tanggal: "",
  keterangan: "",
  status: 1,
});

const getSupplierList = () => {
  useApi("/supplier/all").then(({ data }) => {
    supplierList.value = data;
  });
};

const getBanks = () => {
  useApi("/bank-mitra/all").then(({ data }) => {
    bankList.value = data;
  });
};

// Function to fetch data from the API
const fetchData = async (params = {}) => {
  const baseUrl = `/pengadaan${objectToParams(params)}`;

  useApi(baseUrl).then(({ data }) => {
    if (data) {
      pagination.totalPages = data.pageTotal;
      pagination.page = Number.parseInt(data.currentPage);
      pagination.totalItem = data.total;
      contentData.value = data.items;
    }
  });
};

const deleteItem = async (item) => {
  const { success } = await useApi(`/pengadaan/${item.id}`, {
    withLoader: true,
    method: "DELETE",
  });

  if (success) fetchData(params);
};

const goToPreviousPage = () => {
  if (pagination.page > 1) {
    pagination.page = pagination.page - 1;

    const updatedParams = { ...params, page: pagination.page };

    fetchData(updatedParams);
  }
};

const goToNextPage = () => {
  if (pagination.page < pagination.totalPages) {
    pagination.page = pagination.page + 1;

    const updatedParams = { ...params, page: pagination.page };

    fetchData(updatedParams);
  }
};

watch(selectedBank, (value) => {
  const getId = bankList.value.find((item) => item.text === value)?.id;

  selectedBankId.value = getId;
  if (getId) {
    const updatedParams = { ...params, bank_id: getId };
    if (selectedSupplierId.value)
      updatedParams.supplier_id = selectedSupplierId.value;

    fetchData(updatedParams);
  } else {
    const updatedParams = { ...params };
    if (selectedSupplierId.value)
      updatedParams.supplier_id = selectedSupplierId.value;
    fetchData(updatedParams);
  }
});

watch(selectedSupplier, (value) => {
  const getId = supplierList.value.find((item) => item.text === value)?.id;

  selectedSupplierId.value = getId;
  if (getId) {
    const updatedParams = { ...params, supplier_id: getId };
    if (selectedBankId.value) updatedParams.bank_id = selectedBankId.value;
    fetchData(updatedParams);
  } else {
    const updatedParams = { ...params };
    if (selectedBankId.value) updatedParams.bank_id = selectedBankId.value;
    fetchData(updatedParams);
  }
});

watch(selectedRange, (value) => {
  // panggil api disini
  console.log("filter_range", value);
});

const showApprovalDialog = (item) => {
  useApi(`/pengadaan/${item.id}`).then(({ data }) => {
    const pengadaan = data.pengadaan;

    const form = {
      id: pengadaan.id,
      supplier_name: pengadaan.supplier_name,
      bank_name: `${pengadaan.bank_mitra_code} - ${pengadaan.bank_mitra_name}`,
      po_date: pengadaan.po_date,
      dp: pengadaan.payment,
      description: pengadaan.description,
      detail: data.detail,
      total_price: pengadaan.total_price,
    };

    approvalDialog.value.show(form);
  });
};

const showPaymentDialog = (item) => {
  useApi(`/pengadaan/${item.id}`).then(({ data }) => {
    const pengadaan = data.pengadaan;

    const form = {
      id: pengadaan.id,
      supplier_name: pengadaan.supplier_name,
      bank_name: `${pengadaan.bank_mitra_code} - ${pengadaan.bank_mitra_name}`,
      po_date: pengadaan.po_date,
      dp: pengadaan.payment,
      description: pengadaan.description,
      detail: data.detail,
      total_price: pengadaan.total_price,
      pay_order: 0,
      remaining_payment: pengadaan.total_price - pengadaan.payment,
      order_date: new Date(),
    };

    paymentDialog.value.show(form);
  });
};

onMounted(() => {
  getSupplierList();
  getBanks();
  fetchData(params);
});
</script>

<template>
  <PayOrderDialog
    v-if="tableRef"
    v-slot="{ formData, validationErrors, isEditing }"
    ref="paymentDialog"
    path="pengadaan"
    title="Pembayaran Order"
    edit-title="Pembayaran Order"
    :refresh-callback="
      () => {
        fetchData(params);
      }
    "
  >
    <VCard>
      <!-- 👉 payment offer -->
      <VCardText>
        <div class="d-flex align-center gap-4 flex-wrap">
          <VRow>
            <VCol cols="12" sm="6" md="6">
              <VTextField
                v-model="formData.supplier_name"
                label="Supplier"
                disabled
              />
            </VCol>
            <VCol cols="12" sm="6" md="6">
              <VTextField v-model="formData.bank_name" label="Bank" disabled />
            </VCol>
            <VCol cols="12" sm="6" md="6">
              <VTextField
                v-model="formData.po_date"
                label="Tanggal"
                type="date"
                disabled
              />
            </VCol>
            <VCol cols="12" sm="6" md="6">
              <VTextField
                v-model="formData.dp"
                label="DP Pembayaran"
                type="number"
                disabled
              />
            </VCol>
            <VCol cols="12" sm="12" md="12">
              <VTextarea
                v-model="formData.description"
                label="Deskripsi"
                rows="2"
                disabled
              />
            </VCol>
          </VRow>
        </div>
      </VCardText>
      <VCardText>
        <h6 class="text-h6 mb-4">Item Detail</h6>
        <div
          v-if="formData.detail.length > 0"
          class="text-sm text-high-emphasis"
        >
          <div
            v-for="(item, index) in formData.detail"
            :key="`detailItems${index}`"
            class="d-flex justify-space-between mb-2"
          >
            <div
              class="text-body-1 text-high-emphasis"
              style="max-inline-size: 250px"
            >
              {{ item.product_name }}
            </div>
            <div class="d-flex gap-x-4">
              <div class="text-body-1">
                {{ rupiahFormater(item.price) }}
              </div>
              <div class="text-body-1 text-disabled">x [{{ item.qty }}] =</div>
              <div class="text-body-1">
                {{ rupiahFormater(item.total) }}
              </div>
            </div>
          </div>
        </div>

        <div v-else>
          <p>Tidak ada produk yang ditambahkan.</p>
        </div>
      </VCardText>
      <VCardText class="d-flex justify-space-between">
        <h6 class="text-h6">Total</h6>
        <h6 class="text-h6">
          {{ rupiahFormater(formData.total_price) }}
        </h6>
      </VCardText>
      <VCardText>
        <div class="d-flex align-center gap-4 flex-wrap">
          <VRow>
            <VCol cols="12" sm="6" md="6">
              <VTextField
                v-model="formData.pay_order"
                :label="`Sisa Pembayaran (${rupiahFormater(
                  formData.remaining_payment
                )})`"
                type="number"
                :max="formData.remaining_payment"
              />
            </VCol>
            <VCol cols="12" sm="6" md="6">
              <VTextField
                v-model="formData.order_date"
                label="Tanggal Pembayaran"
                type="date"
              />
            </VCol>
          </VRow>
        </div>
      </VCardText>
    </VCard>
  </PayOrderDialog>
  <ApprovalDialog
    v-if="tableRef"
    v-slot="{ formData, validationErrors, isEditing }"
    ref="approvalDialog"
    path="pengadaan"
    title="Konfirmasi Pengadaan"
    edit-title="Konfirmasi Pengadaan"
    :refresh-callback="
      () => {
        fetchData(params);
      }
    "
  >
    <VCard>
      <!-- 👉 payment offer -->
      <VCardText>
        <div class="d-flex align-center gap-4 flex-wrap">
          <VRow>
            <VCol cols="12" sm="6" md="6">
              <VTextField
                v-model="formData.supplier_name"
                label="Supplier"
                disabled
              />
            </VCol>
            <VCol cols="12" sm="6" md="6">
              <VTextField v-model="formData.bank_name" label="Bank" disabled />
            </VCol>
            <VCol cols="12" sm="6" md="6">
              <VTextField
                v-model="formData.po_date"
                label="Tanggal"
                type="date"
                disabled
              />
            </VCol>
            <VCol cols="12" sm="6" md="6">
              <VTextField
                v-model="formData.dp"
                label="DP Pembayaran"
                type="number"
                disabled
              />
            </VCol>
            <VCol cols="12" sm="12" md="12">
              <VTextarea
                v-model="formData.description"
                label="Deskripsi"
                rows="2"
                disabled
              />
            </VCol>
          </VRow>
        </div>
      </VCardText>
      <VCardText>
        <h6 class="text-h6 mb-4">Item Detail</h6>
        <div
          v-if="formData.detail.length > 0"
          class="text-sm text-high-emphasis"
        >
          <div
            v-for="(item, index) in formData.detail"
            :key="`detailItems${index}`"
            class="d-flex justify-space-between mb-2"
          >
            <div
              class="text-body-1 text-high-emphasis"
              style="max-inline-size: 250px"
            >
              {{ item.product_name }}
            </div>
            <div class="d-flex gap-x-4">
              <div class="text-body-1">
                {{ rupiahFormater(item.price) }}
              </div>
              <div class="text-body-1 text-disabled">x [{{ item.qty }}] =</div>
              <div class="text-body-1">
                {{ rupiahFormater(item.total) }}
              </div>
            </div>
          </div>
        </div>

        <div v-else>
          <p>Tidak ada produk yang ditambahkan.</p>
        </div>
      </VCardText>
      <VCardText class="d-flex justify-space-between">
        <h6 class="text-h6">Total</h6>
        <h6 class="text-h6">
          {{ rupiahFormater(formData.total_price) }}
        </h6>
      </VCardText>
    </VCard>
  </ApprovalDialog>

  <VRow>
    <VCol cols="12" md="12" sm="12">
      <div>
        <VCard class="logistics-card-statistics cursor-pointer">
          <VCardText>
            <VRow>
              <VCol cols="4">
                <VAutocomplete
                  v-model="selectedBank"
                  label="Bank"
                  placeholder="Pilih Bank"
                  :items="bankList"
                  item-title="text"
                  item-value="value"
                  variant="outlined"
                  clearable
                  clear-icon="ri-close-line"
                />
              </VCol>

              <VCol cols="4">
                <VAutocomplete
                  v-model="selectedSupplier"
                  label="Supplier"
                  placeholder="Pilih Supplier"
                  :items="supplierList"
                  item-title="text"
                  item-value="value"
                  variant="outlined"
                  clearable
                  clear-icon="ri-close-line"
                />
              </VCol>

              <VCol cols="4">
                <AppDateTimePicker
                  v-model="selectedRange"
                  label="Range"
                  placeholder="Select date"
                  :config="{ mode: 'range' }"
                />
              </VCol>
            </VRow>
          </VCardText>
        </VCard>
      </div>
    </VCol>

    <VCol cols="12">
      <VDataTable
        ref="tableRef"
        v-model:page="pagination.page"
        :headers="headers"
        :items="contentData"
        :search="params.search"
        :items-per-page="pagination.itemsPerPage"
        :page-count="pagination.totalPages"
        class="text-no-wrap"
      >
        <template #[`item.price`]="{ item }">
          {{ rupiahFormater(item.price) }}
        </template>

        <template #[`item.actions`]="{ item }">
          <div class="d-flex gap-1">
            <IconBtn size="small" @click="() => showApprovalDialog(item)">
              <VIcon icon="ri-check-double-line" />
            </IconBtn>
            <IconBtn
              :disabled="item.payment === item.total_price"
              size="small"
              @click="() => showPaymentDialog(item)"
            >
              <VIcon icon="ri-money-dollar-box-line" />
            </IconBtn>
            <IconBtn
              :disabled="item.status === 2"
              size="small"
              @click="
                () => {
                  if (item.status !== 2) {
                    confirmDialog.show({
                      title: 'Hapus Data Pengadaan',
                      message: `Anda yakin ingin menghapus data ini?`,
                      onConfirm: () => deleteItem(item),
                    });
                  }
                }
              "
            >
              <VIcon icon="ri-delete-bin-line" />
            </IconBtn>
          </div>
        </template>

        <!-- Pagination -->
        <template #bottom>
          <VDivider />
          <div class="d-flex justify-end flex-wrap gap-x-6 px-2 py-1">
            <div
              class="d-flex align-center gap-x-2 text-medium-emphasis text-base"
            >
              Total Data: <b>{{ pagination.totalItem }}</b>
            </div>
            <div class="d-flex gap-x-2 align-center me-2">
              <VBtn
                class="flip-in-rtl"
                icon="ri-arrow-left-s-line"
                variant="text"
                density="comfortable"
                color="high-emphasis"
                @click="goToPreviousPage"
              />
              Halaman: <b>{{ pagination.page }}</b>
              <VBtn
                class="flip-in-rtl"
                icon="ri-arrow-right-s-line"
                density="comfortable"
                variant="text"
                color="high-emphasis"
                @click="goToNextPage"
              />
            </div>
          </div>
        </template>
      </VDataTable>
    </VCol>
  </VRow>
</template>
