<script setup lang="ts">
import { useRuntimeConfig } from '#app'; // Import useRuntimeConfig
import { onMounted, reactive, ref, watch } from 'vue';
import { VCol, VRow } from 'vuetify/lib/components/index.mjs';

  const config = useRuntimeConfig();

  // State for edit and delete confirmation dialogs
  const contentData = ref([]);
  const saldoData = ref([]);
  const listBank = ref([]);  // List of doctors
  const filter_bank_id = ref();
  const filter_range = ref();
  const filter_type = ref(0);
  
  const listType = [
    { text: 'Select Type ', value: 0 },
    { text: 'Debit', value: 'Debit' },
    { text: 'Kredit', value: 'Kredit' },
  ];

  const totalDebit = ref('');
  const totalKredit = ref('');

  const search = ref('');
  const pagination = reactive({ page: 1, itemsPerPage: 10, totalPages: 0 });
  let value_page = 1;
  let total_item = 0;

  // Headers for the table
  const headers = [
    { title: 'Date', key: 'created_date', sortable: false },
    { title: 'Bank', key: 'bank', sortable: false },
    { title: 'Nominal', key: 'nominal', sortable: false },
    { title: 'Description', key: 'description', sortable: false },
    { title: 'Type', key: 'type', sortable: false },
    { title: 'Source', key: 'source', sortable: false },
  ];

  // Function to fetch data from the API
  const fetchData = async () => {
    try {

      const response = await fetch(`http://localhost:3003/api/finance/saldo/history?page=${pagination.page}&itemsPerPage=${pagination.itemsPerPage}&search=${search.value}&bank_id=${filter_bank_id.value}&type=${filter_type.value}&range=${filter_range.value}`);
      if (!response.ok) {
        throw new Error('Failed to fetch data');
      }
      const data = await response.json();
      contentData.value = data.items;
      totalDebit.value = data.totalDebit;
      totalKredit.value = data.totalKredit;
      total_item = data.totalItems;
      pagination.totalPages = data.totalPages; 
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const fetchSaldo = async () => {
    try {
      const response = await fetch(`http://localhost:3003/api/finance/saldo?page=${pagination.page}&itemsPerPage=${pagination.itemsPerPage}&search=${search.value}`);
      if (!response.ok) {
        throw new Error('Failed to fetch data');
      }
      const data = await response.json();
      console.log(data);
      saldoData.value = data.items;
      
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  // Fetch data when the component is mounted
  onMounted(async () => {
    await Promise.all([
      fetchData(),
      fetchSaldo(),
      fetchListBank()
    ]);
  });


  // Watch pagination or search changes to refetch data
  watch(
    () => [pagination.itemsPerPage, search.value, filter_bank_id.value, filter_type.value, filter_range.value],
    () => {
      fetchData();
    }
  );

  // Pagination functions
  const goToNextPage = () => {
    if (pagination.page < pagination.totalPages) {
      value_page += 1;
      pagination.page = value_page;
      fetchData();
    }
  };

  const goToPreviousPage = () => {
    if (value_page > 1) {
      value_page -= 1;
      pagination.page = value_page;
      fetchData();
    }
  };

  const fetchListBank = async () => {
    try {
      const response = await fetch(`http://localhost:3003/api/finance/income/listBank`);
      if (!response.ok) {
        throw new Error('Failed to fetch list of banks');
      }
      const data = await response.json();
      listBank.value = [
        ...data.list.map((bank: any) => ({
          text: bank.name, // Label for the dropdown
          value: bank.id   // Value associated with the label
        }))
      ];
    } catch (error) {
      console.error('Error fetching banks:', error);
    }
  };

  const card_color = 'info';
  const card_icon = 'ri-money-dollar-box-line';
  const card_icon_debit = 'ri-corner-right-up-line';
  const card_icon_kredit = 'ri-corner-right-down-line';
</script>

<template>
  <VRow>
    <VRow style="margin-block-end: 10px;">
      <VCol
        v-for="item in saldoData"
        :key="item.id"
        cols="12"
        md="3"
        sm="6"
      >
        <div>
          <VCard
            class="logistics-card-statistics cursor-pointer"
            :style="`border-block-end-color: rgb(var(--v-theme-${card_color}))`"
          >
            <VCardText>
              <div class="d-flex align-center gap-x-4 mb-2">
                <VAvatar
                  variant="tonal"
                  :color="card_color"
                  rounded="lg"
                >
                  <VIcon
                    :icon="card_icon"
                    size="24"
                  />
                </VAvatar>
                <h4 class="text-h4">
                  Rp {{ item.nominal }}
                </h4>
              </div>
              <div class="text-body-1 text-high-emphasis">
                Saldo {{ item.bank }}
              </div>
            </VCardText>
          </VCard>
        </div>
      </VCol>
      <VCol
        cols="12"
        md="3"
        sm="6"
      >
        <div>
          <VCard
            class="logistics-card-statistics cursor-pointer"
            :style="`border-block-end-color: rgb(var(--v-theme-${card_color}))`"
          >
            <VCardText>
              <div class="d-flex align-center gap-x-4 mb-2">
                <VAvatar
                  variant="tonal"
                  :color="card_color"
                  rounded="lg"
                >
                  <VIcon
                    :icon="card_icon_debit"
                    size="24"
                  />
                </VAvatar>
                <h4 class="text-h4">
                  {{ totalDebit }}
                </h4>
              </div>
              <div class="text-body-1 text-high-emphasis">
                Total Debit
              </div>
            </VCardText>
          </VCard>
        </div>
      </VCol>
      <VCol
        cols="12"
        md="3"
        sm="6"
      >
        <div>
          <VCard
            class="logistics-card-statistics cursor-pointer"
            :style="`border-block-end-color: rgb(var(--v-theme-${card_color}))`"
          >
            <VCardText>
              <div class="d-flex align-center gap-x-4 mb-2">
                <VAvatar
                  variant="tonal"
                  :color="card_color"
                  rounded="lg"
                >
                  <VIcon
                    :icon="card_icon_kredit"
                    size="24"
                  />
                </VAvatar>
                <h4 class="text-h4">
                  {{ totalKredit }}
                </h4>
              </div>
              <div class="text-body-1 text-high-emphasis">
                Total Kredit
              </div>
            </VCardText>
          </VCard>
        </div>
      </VCol>
      <VCol
        cols="12"
        md="12"
        sm="12"
      >
        <div>
          <VCard
            class="logistics-card-statistics cursor-pointer"
          >
          <VCardText>
            <VRow>
              <VCol cols="12" md="2">
                <VAutocomplete
                  v-model="filter_bank_id"
                  label="Bank"
                  density="compact"
                  placeholder="Select Bank"
                  :items="listBank"
                  item-title="text"
                  item-value="value"
                  variant="outlined"
                />
              </VCol>
              <VCol cols="12" md="2">
                <VSelect 
                  v-model="filter_type" 
                  :items="listType" 
                  item-title="text" 
                  item-value="value" 
                  label="Type"
                  variant="outlined"
                />
              </VCol>
              <VCol cols="12" md="4">
                <AppDateTimePicker
                  v-model="filter_range"
                  label="Range"
                  placeholder="Select date"
                  :config="{ mode: 'range' }"
                />
              </VCol>
              <VCol cols="12" md="4">
                <VTextField
                  v-model="search"
                  label="Search"
                  placeholder="Search ..."
                  append-inner-icon="ri-search-line"
                  single-line
                  hide-details
                  dense
                  outlined
                />
              </VCol>
            </VRow>
          </VCardText>
          </VCard>
        </div>
      </VCol>
    </VRow>
    

    <!-- Data Table -->
    <VDataTable
      :headers="headers"
      :items="contentData"
      :search="search"
      :items-per-page="pagination.itemsPerPage"
      v-model:page="pagination.page"
      :page-count="pagination.totalPages"
      class="text-no-wrap"
    >
      <template v-slot:[`item.actions`]="{ item }">
      </template>

      <!-- Pagination -->
      <template #bottom>
        <VDivider />
        <div class="d-flex justify-end flex-wrap gap-x-6 px-2 py-1">
          <div class="d-flex align-center gap-x-2 text-medium-emphasis text-base">
            Total Data: <b>{{total_item}}</b> - Baris / Halaman:
            <VSelect
              v-model="pagination.itemsPerPage"
              class="per-page-select"
              variant="plain"
              :items="[10, 20, 25, 50, 100]"
            />
          </div>
          <div class="d-flex gap-x-2 align-center me-2">
            <VBtn
              class="flip-in-rtl"
              icon="ri-arrow-left-s-line"
              variant="text"
              density="comfortable"
              color="high-emphasis"
              @click="goToPreviousPage"
            />
            Halaman: <b>{{value_page}}</b>
            <VBtn
              class="flip-in-rtl"
              icon="ri-arrow-right-s-line"
              density="comfortable"
              variant="text"
              color="high-emphasis"
              @click="goToNextPage"
            />
          </div>
        </div>
      </template>
    </VDataTable>
  </VRow>
</template>

<style lang="scss" scoped>
  @use "@core/scss/base/mixins" as mixins;

  .logistics-card-statistics {
    border-block-end-style: solid;
    border-block-end-width: 2px;
  }

</style>
