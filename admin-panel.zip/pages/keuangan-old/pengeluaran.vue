<script setup lang="ts">
import { useRuntimeConfig } from '#app'; // Import useRuntimeConfig
import { onMounted, reactive, ref, watch } from 'vue';
import { VCol, VRow } from 'vuetify/lib/components/index.mjs';

  const config = useRuntimeConfig();

  // State for edit and delete confirmation dialogs
  const addDialog = ref(false);
  const editDialog = ref(false);
  const deleteDialog = ref(false);
  const itemToDelete = ref<number | null>(null) // Store the ID of the item to be deleted
  const contentData = ref([]);
  const listBank = ref([]);  // List of doctors


  const search = ref('');
  const pagination = reactive({ page: 1, itemsPerPage: 10, totalPages: 0 });
  let value_page = 1;
  let total_item = 0;

  // Form data
  const form_id = ref(0);
  const form_bank_id = ref();
  const form_date_out = ref('');
  const form_description = ref('');
  const form_status = ref(0);
  const form_nominal = ref('');

  // Headers for the table
  const headers = [
    { title: 'Date', key: 'date_out', sortable: false },
    { title: 'Bank', key: 'bank', sortable: false },
    { title: 'Nominal', key: 'nominal', sortable: false },
    { title: 'Description', key: 'description', sortable: false },
    { title: 'By', key: 'by', sortable: false },
    { title: 'Created Date', key: 'created_date', sortable: false },
    { title: 'Actions', key: 'actions', sortable: false },
  ];

  // Function to fetch data from the API
  const fetchData = async () => {
    try {
      const response = await fetch(`http://localhost:3003/api/finance/spending?page=${pagination.page}&itemsPerPage=${pagination.itemsPerPage}&search=${search.value}`);
      if (!response.ok) {
        throw new Error('Failed to fetch data');
      }
      const data = await response.json();
      contentData.value = data.items;
      total_item = data.totalItems;
      pagination.totalPages = data.totalPages; 
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  // Fetch data when the component is mounted
  onMounted(fetchData);

  // Watch pagination or search changes to refetch data
  watch(
    () => [pagination.itemsPerPage, search.value],
    () => {
      fetchData();
    }
  );

  // Pagination functions
  const goToNextPage = () => {
    if (pagination.page < pagination.totalPages) {
      value_page += 1;
      pagination.page = value_page;
      fetchData();
    }
  };

  const goToPreviousPage = () => {
    if (value_page > 1) {
      value_page -= 1;
      pagination.page = value_page;
      fetchData();
    }
  };

  // Function to reset the form
  const resetForm = () => {
    form_id.value = 0;
    form_bank_id.value = null;
    form_date_out.value = '';
    form_description.value = '';
    form_nominal.value = '';
    form_status.value = 0;
  };

  const fetchListBank = async () => {
  try {
    const response = await fetch(`http://localhost:3003/api/finance/spending/listBank`);
    if (!response.ok) {
      throw new Error('Failed to fetch list of banks');
    }
    const data = await response.json();
    console.log(data);
    listBank.value = [
      ...data.list.map((bank: any) => ({
        text: bank.name, // Label for the dropdown
        value: bank.id   // Value associated with the label
      }))
    ];
  } catch (error) {
    console.error('Error fetching banks:', error);
  }
};

  const openAddDialog = () => {
    resetForm();
    fetchListBank();
    addDialog.value = true;
  };

  const addItem = async () => {
    try {      
      const response = await fetch(`http://localhost:3003/api/finance/spending`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          bank_id: form_bank_id.value,
          date_out: form_date_out.value,
          description: form_description.value,
          nominal: form_nominal.value,
          status: 1,
          created_by: 'Soni',
          created_at: '2024-09-09 00:00:00',
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to add item');
      }

      await fetchData();

      // Close the dialog and reset the form
      addDialog.value = false;
      resetForm();

    } catch (error) {
      console.error('Error adding item:', error);
    }
  };

  // Function to open the edit dialog and populate form
  const editItem = (item: any) => {
    form_id.value = item.id;
    fetchListBank();
    form_bank_id.value = item.bank_id;
    
    const parsedDate = new Date(item.date_out);
    const year = parsedDate.getFullYear();
    const month = String(parsedDate.getMonth() + 1).padStart(2, '0'); // Month is zero-indexed
    const day = String(parsedDate.getDate()).padStart(2, '0');
    form_date_out.value = `${year}-${month}-${day}`;

    form_description.value = item.description;
    form_nominal.value = item.nominal;
    form_status.value = item.status;
    editDialog.value = true;
  };

  // Function to update the item
  const updated = async () => {
    try {
      const response = await fetch(`http://localhost:3003/api/finance/spending/${form_id.value}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          bank_id: form_bank_id.value,
          date_out: form_date_out.value,
          description: form_description.value,
          nominal: form_nominal.value.replace(/[^0-9]/g, ""),
          status: 1,
          updated_by: 'Soni',
          updated_at: '2024-09-09 00:00:00',
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to update item');
      }
      
      fetchData();

      // Close the dialog and reset the form
      editDialog.value = false;
      resetForm();

    } catch (error) {
      console.error('Error updating item:', error);
    }
  };

  // Function to trigger the delete dialog
  const deleteItem = (itemId: number) => {
    itemToDelete.value = itemId;
    deleteDialog.value = true;
  };

  // Function to confirm the deletion
  const deleteItemConfirm = async () => {
    try {
      if (!itemToDelete.value) return;

      const response = await fetch(`http://localhost:3003/api/finance/spending/${itemToDelete.value}`, {
        method: 'DELETE',
      });

      if (!response.ok) {
        throw new Error('Failed to delete item');
      }

      // Remove the deleted item from contentData
      await fetchData();
      
      // Close the dialog
      deleteDialog.value = false;
      itemToDelete.value = null; // Reset the selected item for deletion

    } catch (error) {
      console.error('Error deleting item:', error);
    }
  };

  // Function to close the delete dialog without deleting
  const closeDelete = () => {
    deleteDialog.value = false;
    itemToDelete.value = null;
  };

  // Function to close the edit dialog
  const close = () => {
    editDialog.value = false;
    addDialog.value = false;
    resetForm();
  };

  // Watcher to format form_nominal as Rupiah

  watch(form_nominal, (newVal) => {
    if (newVal) {
      form_nominal.value = formatRupiah(newVal.replace(/[^0-9]/g, ""));
    }
  });

  // Function to format as Rupiah and allow only numeric input
  function formatRupiah(value: string, prefix: string = "Rp") {
    let split = value.split(",");
    let sisa = split[0].length % 3;
    let rupiah = split[0].substr(0, sisa);
    let ribuan = split[0].substr(sisa).match(/\d{3}/gi);

    if (ribuan) {
      let separator = sisa ? "." : "";
      rupiah += separator + ribuan.join(".");
    }

    rupiah = split[1] != undefined ? rupiah + "," + split[1] : rupiah;
    return prefix == undefined ? rupiah : rupiah ? rupiah : "";
  }

</script>

<template>
  <VRow>
    <VRow style="margin-block-end: 10px;">
      <VCol
        cols="12"
        md="12"
        sm="12"
      >
        <div>
          <VCard
            class="logistics-card-statistics cursor-pointer"
          >
          <VCardText>
            <VRow>
              <VCol cols="2" md="2">
                <VBtn @click="openAddDialog" size="large">
                  <VIcon
                    start
                    icon="ri-add-circle-line"
                  />
                  Add - Spending
                </VBtn>
              </VCol>
              <VCol cols="8" offset-md="6" md="4">
                <VTextField
                  v-model="search"
                  label="Search"
                  placeholder="Search ..."
                  append-inner-icon="ri-search-line"
                  single-line
                  hide-details
                  dense
                  outlined
                />
              </VCol>
            </VRow>
          </VCardText>
          </VCard>
        </div>
      </VCol>
    </VRow>
    

    <!-- Data Table -->
    <VDataTable
      :headers="headers"
      :items="contentData"
      :search="search"
      :items-per-page="pagination.itemsPerPage"
      v-model:page="pagination.page"
      :page-count="pagination.totalPages"
      class="text-no-wrap"
    >
      <template v-slot:[`item.actions`]="{ item }">
        <div class="d-flex gap-1">
          <IconBtn size="small" @click="editItem(item)">
            <VIcon icon="ri-pencil-line" />
          </IconBtn>
          <IconBtn size="small" @click="deleteItem(item.id)">
            <VIcon icon="ri-delete-bin-line" />
          </IconBtn>
        </div>
      </template>

      <!-- Pagination -->
      <template #bottom>
        <VDivider />
        <div class="d-flex justify-end flex-wrap gap-x-6 px-2 py-1">
          <div class="d-flex align-center gap-x-2 text-medium-emphasis text-base">
            Total Data: <b>{{total_item}}</b> - Baris / Halaman:
            <VSelect
              v-model="pagination.itemsPerPage"
              class="per-page-select"
              variant="plain"
              :items="[10, 20, 25, 50, 100]"
            />
          </div>
          <div class="d-flex gap-x-2 align-center me-2">
            <VBtn
              class="flip-in-rtl"
              icon="ri-arrow-left-s-line"
              variant="text"
              density="comfortable"
              color="high-emphasis"
              @click="goToPreviousPage"
            />
            Halaman: <b>{{value_page}}</b>
            <VBtn
              class="flip-in-rtl"
              icon="ri-arrow-right-s-line"
              density="comfortable"
              variant="text"
              color="high-emphasis"
              @click="goToNextPage"
            />
          </div>
        </div>
      </template>
    </VDataTable>
  </VRow>

  <!-- Add Dialog -->
  <VDialog v-model="addDialog" max-width="600px">
    <VCard title="Add - Spending">
      <DialogCloseBtn
        variant="text"
        size="default"
        @click="addDialog = false"
      />

      <VCardText>
        <VContainer>
          <VRow>
            <VCol cols="12" sm="12" md="12">
              <VAutocomplete
                  v-model="form_bank_id"
                  label="Bank"
                  density="compact"
                  placeholder="Select Bank"
                  :items="listBank"
                  item-title="text"
                  item-value="value"
                  required
                />
            </VCol>
            <VCol cols="12" sm="12" md="12">
              <VTextField 
                  type="date"
                  v-model="form_date_out" 
                  label="Date" 
                  placeholder="Select Date"
                />
            </VCol>
            <VCol cols="12" sm="12" md="12">
              <VTextField
                v-model="form_nominal"
                label="Nominal"
                prefix="Rp"
              />
            </VCol>
            <VCol cols="12" sm="12" md="12">
              <VTextField v-model="form_description" label="Description" />
            </VCol>
          </VRow>
        </VContainer>
      </VCardText>

      <VCardActions class="mb-4 mt-2">
        <VSpacer />
        <div class="d-flex flex-wrap gap-4 justify-sm-space-between justify-center mt-8" style="inline-size: 100%;">
          <VBtn color="error" variant="outlined" @click="close">
            <VIcon
              icon="ri-close-circle-line"
              start
              class="flip-in-rtl"
            />
            Cancel&nbsp;
          </VBtn>
          <VBtn variant="outlined" @click="addItem">
            <VIcon
              icon="ri-save-3-line"
              end
              class="flip-in-rtl"
            />
            &nbsp;&nbsp;Save&nbsp;&nbsp;
          </VBtn>
        </div>
      </VCardActions>
    </VCard>
  </VDialog>

  <!-- Edit Dialog -->
  <VDialog v-model="editDialog" max-width="600px">
    <VCard title="Edit - Spending">
      <DialogCloseBtn
        variant="text"
        size="default"
        @click="editDialog = false"
      />

      <VCardText>
        <VContainer>
          <VRow>
            <VCol cols="12" sm="12" md="12">
              <VAutocomplete
                  v-model="form_bank_id"
                  label="Bank"
                  density="compact"
                  placeholder="Select Bank"
                  :items="listBank"
                  item-title="text"
                  item-value="value"
                  required
                />
            </VCol>
            <VCol cols="12" sm="12" md="12">
              <VTextField 
                  type="date"
                  v-model="form_date_out" 
                  label="Date" 
                  placeholder="Select Date"
                />
            </VCol>
            <VCol cols="12" sm="12" md="12">
              <VTextField
                v-model="form_nominal"
                label="Nominal"
                prefix="Rp"
              />
            </VCol>
            <VCol cols="12" sm="12" md="12">
              <VTextField v-model="form_description" label="Description" />
            </VCol>
          </VRow>
        </VContainer>
      </VCardText>

      <VCardActions class="mb-4 mt-2">
        <VSpacer />
        <div class="d-flex flex-wrap gap-4 justify-sm-space-between justify-center mt-8" style="inline-size: 100%;">
          <VBtn color="error" variant="outlined" @click="close">
            <VIcon
              icon="ri-close-circle-line"
              start
              class="flip-in-rtl"
            />
            Cancel&nbsp;
          </VBtn>
          <VBtn variant="outlined" @click="updated">
            <VIcon
              icon="ri-save-3-line"
              end
              class="flip-in-rtl"
            />
            &nbsp;&nbsp;Save&nbsp;&nbsp;
          </VBtn>
        </div>
      </VCardActions>
    </VCard>
  </VDialog>

  <!-- Delete Confirmation Dialog -->
  <VDialog v-model="deleteDialog" max-width="500px">
    <VCard>
      <!-- Centered title -->
      <VCardTitle class="text-center mt-4">
        Are you sure you want to delete this item?
      </VCardTitle>

      <!-- Centered progress circular -->
      <VCardText class="d-flex justify-center">
        <VProgressCircular
          :size="100"
          color="primary"
          indeterminate
        />
      </VCardText>

      <VCardActions class="mb-4 mt-2">
        <VSpacer />
        <!-- Centered buttons: Cancel and OK -->
        <div
          class="d-flex justify-center gap-4"
          style="inline-size: 100%;"
        >
          <VBtn color="error" variant="outlined" @click="closeDelete">
            <VIcon icon="ri-close-circle-line" start class="flip-in-rtl" />
            Cancel&nbsp;
          </VBtn>
          <VBtn variant="outlined" @click="deleteItemConfirm">
            <VIcon icon="ri-save-3-line" end class="flip-in-rtl" />
            &nbsp;&nbsp;OK&nbsp;&nbsp;
          </VBtn>
        </div>
        <VSpacer />
      </VCardActions>
    </VCard>
  </VDialog>

</template>

<style lang="scss" scoped>
  @use "@core/scss/base/mixins" as mixins;

  .logistics-card-statistics {
    border-block-end-style: solid;
    border-block-end-width: 2px;
  }

</style>
