<script setup lang="ts">
import type { ProductItem } from "@/types";
import jsPDF from "jspdf";
import "jspdf-autotable";
import { onMounted, reactive, ref } from "vue";
import { VTextField } from "vuetify/lib/components/index.mjs";

const { confirmDialog } = useCommonStore();

const contentData = ref([]);
const isShowDialog = ref(false);
const cabangList = ref([]);
const categoryList = ref([]);
const pelangganList = ref([]);

const pagination = reactive({
  page: 1,
  itemsPerPage: 10,
  totalPages: 0,
  totalItem: 0,
});

const params = reactive({ itemsPerPage: 5, limit: 5, page: 1, search: "" });

// Headers for the table
const headers = [
  { title: "Product", key: "name", sortable: false },
  { title: "Price", key: "price", sortable: false },
  { title: "Stock", key: "stock", sortable: false },
  { title: "", key: "actions", sortable: false, align: "end" },
];

const selectedCabang = ref(null);
const selectedCategory = ref(null);

const orderForm = ref({
  cabang_id: null,
  anggota_id: null,
  date_order: null,
  description: "",
  total_price: 45000,
  detail: [
    {
      product_id: 1,
      price: 10000,
      qty: 2,
      total: 20000,
    },
    {
      product_id: 2,
      price: 5000,
      qty: 1,
      total: 5000,
    },
  ],
});

const detailItems = ref<ProductItem[]>([]);
const selectedItem = ref<ProductItem>({});

const totalPrice = computed(() => {
  if (detailItems.value.length === 0) return 0;

  return detailItems.value.reduce((acc, item) => acc + item.total, 0);
});

// Function to fetch data from the API
const fetchData = async (params = {}, categoryId = 0) => {
  const baseUrl = `/product/paginate-by-category/${categoryId}`;

  useApi(baseUrl).then(({ data }) => {
    if (data) {
      pagination.totalPages = data.pageTotal;
      pagination.page = Number.parseInt(data.currentPage);
      pagination.totalItem = data.total;
      contentData.value = data.items;
    }
  });
};

const getCabangList = () => {
  useApi("/cabang/all").then(({ data }) => {
    cabangList.value = data;
  });
};

const getPelangganList = () => {
  useApi("/anggota/list-data").then(({ data }) => {
    pelangganList.value = data;
  });
};

const getCategories = () => {
  useApi("category-product/all").then(({ data }) => {
    categoryList.value = data;
  });
};


const showAddItemDialog = (item) => {
  selectedItem.value = { ...item, qty: 1 };
  isShowDialog.value = true;
};

const addItem = () => {
  const getIndex = detailItems.value.findIndex(
    (i) => i.id === selectedItem.value.id
  );

  if (getIndex >= 0) {
    const updatedQty =
      Number.parseInt(selectedItem.value.qty) +
      Number.parseInt(detailItems.value[getIndex].qty);

    detailItems.value[getIndex].total = selectedItem.value.price * updatedQty;
    detailItems.value[getIndex].qty = updatedQty;
  } else {
    const addedItem = {
      ...selectedItem.value,
      total: selectedItem.value.price * Number.parseInt(selectedItem.value.qty),
      qty: Number.parseInt(selectedItem.value.qty),
    };

    detailItems.value.push(addedItem);
  }

  isShowDialog.value = false;
};

const removeItem = (index) => {
  detailItems.value.splice(index, 1);
};

const submitTransaction = async () => {

  const payload = JSON.parse(JSON.stringify(orderForm.value));
  payload.anggota_id = Number(payload.anggota_id);

  payload.detail = detailItems.value.map((item) => {
    return {
      product_id: item.id,
      price: item.price,
      qty: item.qty,
      total: item.total,
    };
  });
  payload.total_price = totalPrice.value;

  const { errors, success } = await useApi("/order", {
    withNotif: true,
    method: "POST",
    data: payload,
  });

  if (success) printInvoice();
};

const cleanData = () => {
  orderForm.value.cabang_id = null;
  orderForm.value.anggota_id = null;
  detailItems.value = [];
  orderForm.value.detail = [];
  orderForm.value.date_order = null;
  orderForm.value.description = "";
};

const printInvoice = () => {
  // Setup Doc
  const doc = new jsPDF({
    format: [200, 100],
    unit: "mm",
  });

  const startingXPos = 10;
  const startingYPos = 10;
  const distance = 6;
  const pageWidth = doc.internal.pageSize.getWidth();
  const getCenterWidth = pageWidth / 2;

  // Setup Fonts
  const fontType = "helvetica";

  doc.setFont(fontType, "bold");

  // Header
  doc.setFontSize(14);
  doc.text("Khalisa Medic", getCenterWidth, startingYPos, {
    align: "center",
  });
  doc.setFont(fontType, "normal");
  doc.setFontSize(11);
  let nextYPos = startingYPos + distance;
  doc.text("tukangbikin.web.id@gmail.com", getCenterWidth, nextYPos, {
    align: "center",
  });
  nextYPos = nextYPos + distance;
  doc.text("+62 896-5248-3516", getCenterWidth, nextYPos, {
    align: "center",
  });

  // DIVIDER
  nextYPos = nextYPos + distance;
  doc.line(startingXPos, nextYPos, pageWidth - startingXPos, nextYPos);

  // DATE TIME
  nextYPos = nextYPos + distance + 3;

  const selectedTime = orderForm.value.date_order;

  doc.text("Tanggal", startingXPos, nextYPos);
  doc.text(
    selectedTime,
    pageWidth + startingXPos - doc.getTextWidth(selectedTime),
    nextYPos,
    {
      align: "right",
    }
  );

  // MARKETPLACE
  nextYPos = nextYPos + distance + 3;

  const selectedMp = orderForm.value.cabang_id;

  // DIVIDER
  nextYPos = nextYPos + distance;
  doc.line(startingXPos, nextYPos, pageWidth - startingXPos, nextYPos);

  // ITEM DETAILS
  doc.setFontSize(10);
  if (detailItems.value.length > 0) {
    detailItems.value.map((item, index) => {
      const offset = index === 0 ? distance + 2 : 12;

      nextYPos = nextYPos + offset;
      doc.setFont(fontType, "bold");
      doc.text(item.name, startingXPos, nextYPos);
      doc.setFont(fontType, "normal");
      doc.text(`${item.qty} + ${item.price}`, startingXPos, nextYPos + 5);
      doc.text(
        item.total.toString(),
        pageWidth - doc.getTextWidth(item.total.toString()),
        nextYPos,
        {
          align: "right",
        }
      );
    });
  }

  // DIVIDER
  nextYPos = nextYPos + distance + 5;
  doc.line(startingXPos, nextYPos, pageWidth - startingXPos, nextYPos);

  // TOTAL
  nextYPos = nextYPos + distance;
  doc.setFontSize(11);
  doc.setFont(fontType, "bold");
  doc.text("Total", startingXPos, nextYPos);
  doc.setFont(fontType, "normal");
  doc.text(
    totalPrice.value.toString(),
    pageWidth - doc.getTextWidth(totalPrice.value.toString()),
    nextYPos,
    {
      align: "right",
    }
  );

  // Save the PDF
  doc.save("Invoice.pdf");

  setTimeout(() => {
    cleanData();
  }, 500);
};

const goToPreviousPage = () => {
  if (pagination.page > 1) {
    pagination.page = pagination.page - 1;

    const updatedParams = { ...params, page: pagination.page };

    fetchData(updatedParams);
  }
};

const goToNextPage = () => {
  if (pagination.page < pagination.totalPages) {
    pagination.page = pagination.page + 1;

    const updatedParams = { ...params, page: pagination.page };

    fetchData(updatedParams);
  }
};

onMounted(() => {
  fetchData(params);
  getCategories();
  getCabangList();
  getPelangganList();
});
</script>

<template>
  <VRow>
    <!-- Data Table -->
    <VCol cols="12" md="7" sm="7">
      <VRow style="margin-block-end: 10px">
        <VCol cols="12" md="12" sm="12">
          <div>
            <VCard class="logistics-card-statistics cursor-pointer">
              <VCardText>
                <VRow>
                  <VCol
                    v-for="category in categoryList"
                    :key="category"
                    cols="4"
                    md="4"
                  >
                    <VBtn
                      :color="
                        selectedCategory === category ? 'primary' : 'secondary'
                      "
                      block
                      @click.prevent="
                        () => {
                          if (selectedCategory === category) {
                            selectedCategory = null;
                            fetchData(params, 0);
                          } else {
                            selectedCategory = category;
                            fetchData(params, category.id);
                          }
                        }
                      "
                    >
                      {{ category.text }}
                    </VBtn>
                  </VCol>
                </VRow>
                <VRow>
                  <VCol cols="12" md="12" class="ms-md-auto">
                    <VTextField
                      v-model="params.search"
                      label="Search"
                      placeholder="Search ..."
                      append-inner-icon="ri-search-line"
                      single-line
                      hide-details
                      dense
                      outlined
                    />
                  </VCol>
                </VRow>
              </VCardText>
            </VCard>
          </div>
        </VCol>
      </VRow>
      <VDataTable
        v-model:page="pagination.page"
        :headers="headers"
        :items="contentData"
        :search="params.search"
        :items-per-page="pagination.itemsPerPage"
        :page-count="pagination.totalPages"
        class="text-no-wrap"
      >
        <template #[`item.price`]="{ item }">
          {{ rupiahFormater(item.price) }}
        </template>
        <template #[`item.stock`]="{ item }"> 20 </template>
        <template #[`item.actions`]="{ item }">
          <div class="d-flex gap-1 justify-end">
            <VBtn
              title="Add Item"
              color="primary"
              variant="outlined"
              size="small"
              @click="showAddItemDialog(item)"
            >
              Add Item
              <VIcon end icon="ri-add-circle-line" />
            </VBtn>
          </div>
        </template>

        <!-- Pagination -->
        <template #bottom>
          <VDivider />
          <div class="d-flex justify-end flex-wrap gap-x-6 px-2 py-1">
            <div
              class="d-flex align-center gap-x-2 text-medium-emphasis text-base"
            >
              Total Data: <b>{{ pagination.totalItem }}</b>
            </div>
            <div class="d-flex gap-x-2 align-center me-2">
              <VBtn
                class="flip-in-rtl"
                icon="ri-arrow-left-s-line"
                variant="text"
                density="comfortable"
                color="high-emphasis"
                @click="goToPreviousPage"
              />
              Halaman: <b>{{ pagination.page }}</b>
              <VBtn
                class="flip-in-rtl"
                icon="ri-arrow-right-s-line"
                density="comfortable"
                variant="text"
                color="high-emphasis"
                @click="goToNextPage"
              />
            </div>
          </div>
        </template>
      </VDataTable>
    </VCol>

    <VCol cols="12" md="5" sm="5">
      <VCard flat variant="outlined">
        <!-- 👉 payment offer -->
        <VCardText>
          <div class="d-flex align-center gap-4 flex-wrap">
            <VRow>
              <VCol cols="12" sm="6" md="6">
                <VTextField
                  v-model="orderForm.date_order"
                  label="Tanggal"
                  type="date"
                />
              </VCol>
              <VCol cols="12" sm="6" md="6">
                <VAutocomplete
                  v-model="orderForm.cabang_id"
                  label="Cabang"
                  placeholder="Pilih Cabang"
                  :items="cabangList"
                  item-title="text"
                  item-value="id"
                  required
                />
              </VCol>
              <VCol cols="12" sm="12" md="12">
                <VAutocomplete
                  v-model="orderForm.anggota_id"
                  label="Pelanggan"
                  placeholder="Pilih Pelanggan"
                  :items="pelangganList"
                  item-title="text"
                  item-value="id"
                  required
                />
              </VCol>
              <VCol cols="12" sm="12" md="12">
                <VTextarea
                  v-model="orderForm.description"
                  label="Deskripsi"
                  rows="2"
                />
              </VCol>
            </VRow>
          </div>
        </VCardText>
        <!-- 👉 Price details -->
        <VCardText>
          <h6 class="text-h6 mb-4">Item Detail</h6>

          <div v-if="detailItems.length > 0" class="text-sm text-high-emphasis">
            <div
              v-for="(item, index) in detailItems"
              :key="`detailItems${index}`"
              class="d-flex justify-space-between mb-2"
            >
              <div
                class="text-body-1 text-high-emphasis"
                style="max-inline-size: 250px"
              >
                {{ item.name }}
              </div>
              <div class="d-flex gap-x-4">
                <div class="text-body-1">
                  {{ rupiahFormater(item.price) }}
                </div>
                <div class="text-body-1 text-disabled">
                  x [{{ item.qty }}] =
                </div>
                <div class="text-body-1">
                  {{ rupiahFormater(item.total) }}
                </div>
                <IconBtn
                  size="small"
                  style="margin-block-start: -7px"
                  @click="removeItem(index)"
                >
                  <VIcon icon="ri-delete-bin-line" />
                </IconBtn>
              </div>
            </div>
          </div>

          <div v-else>
            <p>Tidak ada produk yang ditambahkan.</p>
          </div>
        </VCardText>
        <VCardText
          v-if="detailItems.length > 0"
          class="d-flex justify-space-between"
        >
          <h6 class="text-h6">Total</h6>
          <h6 class="text-h6">
            {{ rupiahFormater(totalPrice) }}
          </h6>
        </VCardText>
      </VCard>
      <VBtn block class="mt-4" @click.prevent="submitTransaction"> Order </VBtn>
    </VCol>
  </VRow>
  <VDialog v-model="isShowDialog" max-width="600px">
    <VCard title="Add Item">
      <DialogCloseBtn variant="text" size="default" @click="close" />

      <VCardText>
        <VContainer>
          <VRow>
            <VCol cols="12" sm="8" md="6">
              <VTextField v-model="selectedItem.name" label="Produk" readonly />
            </VCol>
            <VCol cols="12" sm="4" md="3">
              <VTextField
                v-model="selectedItem.qty"
                type="number"
                label="Qty"
                :min="1"
              />
            </VCol>
            <VCol cols="12" sm="4" md="3">
              <VBtn
                variant="outlined"
                style="
                  block-size: 44px;
                  inline-size: 100%;
                  margin-block-start: 2px;
                "
                @click="addItem"
              >
                Add&nbsp;&nbsp;&nbsp;
                <VIcon icon="ri-save-3-line" end class="flip-in-rtl" />
              </VBtn>
            </VCol>
          </VRow>
        </VContainer>
      </VCardText>
    </VCard>
  </VDialog>
</template>

<style lang="scss" scoped>
@use "@core/scss/base/mixins" as mixins;

.logistics-card-statistics {
  border-block-end-style: solid;
  border-block-end-width: 2px;
}
</style>
