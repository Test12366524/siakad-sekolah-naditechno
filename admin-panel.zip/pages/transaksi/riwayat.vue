<script setup lang="ts">
import { useRuntimeConfig } from '#app';
import { onMounted, reactive, ref, watch } from 'vue';
import { VCol, VRow } from 'vuetify/lib/components/index.mjs';

  const config = useRuntimeConfig();

  const historyPaymentDialog = ref(false);
  const contentData = ref([]);
  const listSupplier = ref([]); 
  const listMedicine = ref([]); 
  
  const itemToAccepted = ref<number | null>(null);
  const itemToPayment = ref<number | null>(null);

  const filter_range = ref();
  const filter_type = ref(0);
  const listType = [
    { text: 'Select Type ', value: 0 },
    { text: 'Paid off', value: 'Paid off' },
    { text: 'Debt', value: 'Debt' },
  ];

  const totalPrice = ref('');
  const totalPatient = ref('');
  const totalNonPatient = ref('');

  const search = ref('');
  const pagination = reactive({ page: 1, itemsPerPage: 10, totalPages: 0 });
  let value_page = 1;
  let total_item = 0;

  const form_id = ref(0);
  const form_name = ref();
  const form_date = ref('');
  const form_description = ref('');
  const form_total_price = ref('');
  const form_payment = ref('');

  const itemDetails = ref([]);

  const headers = [
    { title: 'ID', key: 'id', sortable: false },
    { title: 'Date', key: 'transaction_date', sortable: false },
    { title: 'Name', key: 'name', sortable: false },
    { title: 'Total Price', key: 'total_price', sortable: false },
    // { title: 'Payment', key: 'payment', sortable: false },
    { title: 'Description', key: 'description', sortable: false },
    { title: 'Actions', key: 'actions', sortable: false, align: 'end' },
  ];

  const fetchData = async () => {
    try {
      const response = await fetch(`http://localhost:3003/api/transaction/history?page=${pagination.page}&itemsPerPage=${pagination.itemsPerPage}&search=${search.value}&type=${filter_type.value}&range=${filter_range.value}`);
      if (!response.ok) {
        throw new Error('Failed to fetch data');
      }
      const data = await response.json();
      contentData.value = data.items;
      totalPrice.value = data.totalPrice;
      totalPatient.value = data.totalPatient;
      totalNonPatient.value = data.totalNonPatient;
      total_item = data.totalItems;
      pagination.totalPages = data.totalPages; 
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  onMounted(fetchData);

  watch(
    () => [pagination.itemsPerPage, search.value, filter_type.value, filter_range.value],
    () => {
      fetchData();
    }
  );

  const goToNextPage = () => {
    if (pagination.page < pagination.totalPages) {
      value_page += 1;
      pagination.page = value_page;
      fetchData();
    }
  };

  const goToPreviousPage = () => {
    if (value_page > 1) {
      value_page -= 1;
      pagination.page = value_page;
      fetchData();
    }
  };
  const fetchListSupplier = async () => {
    try {
      const response = await fetch(`http://localhost:3003/api/purchase-order/medicine/listSupplier`);
      if (!response.ok) {
        throw new Error('Failed to fetch list of suppliers');
      }
      const data = await response.json();
      listSupplier.value = [
        ...data.list.map((supplier: any) => ({
          text: supplier.name, 
          value: supplier.id
        }))
      ];
    } catch (error) {
      console.error('Error fetching suppliers:', error);
    }
  };

  const fetchListMedicine = async () => {
    try {
      const response = await fetch(`http://localhost:3003/api/purchase-order/medicine/listMedicine`);
      if (!response.ok) {
        throw new Error('Failed to fetch list of itemDetails');
      }
      const data = await response.json();
      listMedicine.value = data.list;
    } catch (error) {
      console.error('Error fetching itemDetails:', error);
    }
  };


  function formatRupiah(value: number | string, prefix: string = "Rp") {
    // Ensure value is a string
    value = value.toString().replace(/[^0-9]/g, "");

    let split = value.split(",");
    let sisa = split[0].length % 3;
    let rupiah = split[0].substr(0, sisa);
    let ribuan = split[0].substr(sisa).match(/\d{3}/gi);

    if (ribuan) {
      let separator = sisa ? "." : "";
      rupiah += separator + ribuan.join(".");
    }

    rupiah = split[1] !== undefined ? rupiah + "," + split[1] : rupiah;
    return prefix === undefined ? rupiah : prefix + " " + rupiah;
  }

  // Function to close the delete dialog without deleting
  const closeDelete = () => {
    historyPaymentDialog.value = false;
  };

  const itemDetail = (item: any) => {
    itemToPayment.value = item.id;

    form_id.value = item.id;
    form_name.value = item.name;
    form_description.value = item.description;
    form_total_price.value = formatRupiah(item.total_price);
    form_payment.value = formatRupiah(item.payment);
    form_date.value = item.transaction_date;


    // Mengisi data untuk detail (itemDetails)
    itemDetails.value = item.itemDetails.map((medicine: any) => ({
      medicine: medicine.medicine,
      price: formatRupiah(medicine.price),
      qty: medicine.qty,
      total: formatRupiah(medicine.total),
    }));

    historyPaymentDialog.value = true;
  };


  const card_color = 'info';
  const card_icon_po = 'ri-numbers-line';
  const card_icon_paid_off = 'ri-money-dollar-box-line';
  const card_icon_debt = 'ri-refund-2-line';
</script>


<template>
  <VRow>
    <VRow style="margin-block-end: 10px;">
      <VCol
        cols="12"
        md="12"
        sm="12"
      >
        <div>
          <VCard class="logistics-card-statistics cursor-pointer">
            <VCardText>
              <VRow>
                <VCol cols="12" md="4">
                  <AppDateTimePicker
                    v-model="filter_range"
                    label="Range"
                    placeholder="Select date"
                    :config="{ mode: 'range' }"
                  />
                </VCol>
                <VCol cols="12" md="8">
                  <VTextField
                    v-model="search"
                    label="Search"
                    placeholder="Search ..."
                    append-inner-icon="ri-search-line"
                    single-line
                    hide-details
                    dense
                    outlined
                  />
                </VCol>
              </VRow>
            </VCardText>
          </VCard>
        </div>
      </VCol>
      <VCol
        cols="12"
        md="4"
        sm="4"
      >
        <div>
          <VCard
            class="logistics-card-statistics cursor-pointer"
            :style="`border-block-end-color: rgb(var(--v-theme-${card_color}))`"
          >
            <VCardText>
              <div class="d-flex align-center gap-x-4 mb-2">
                <VAvatar
                  variant="tonal"
                  :color="card_color"
                  rounded="lg"
                >
                  <VIcon
                    :icon="card_icon_po"
                    size="24"
                  />
                </VAvatar>
                <h4 class="text-h4">
                  {{ totalPrice }}
                </h4>
              </div>
              <div class="text-body-1 text-high-emphasis">
                Total Penjualan
              </div>
            </VCardText>
          </VCard>
        </div>
      </VCol>
      <VCol
        cols="12"
        md="4"
        sm="4"
      >
        <div>
          <VCard
            class="logistics-card-statistics cursor-pointer"
            :style="`border-block-end-color: rgb(var(--v-theme-${card_color}))`"
          >
            <VCardText>
              <div class="d-flex align-center gap-x-4 mb-2">
                <VAvatar
                  variant="tonal"
                  :color="card_color"
                  rounded="lg"
                >
                  <VIcon
                    :icon="card_icon_paid_off"
                    size="24"
                  />
                </VAvatar>
                <h4 class="text-h4">
                  {{ totalPatient }}
                </h4>
              </div>
              <div class="text-body-1 text-high-emphasis">
                Total Anggota
              </div>
            </VCardText>
          </VCard>
        </div>
      </VCol>
      <VCol
        cols="12"
        md="4"
        sm="4"
      >
        <div>
          <VCard
            class="logistics-card-statistics cursor-pointer"
            :style="`border-block-end-color: rgb(var(--v-theme-${card_color}))`"
          >
            <VCardText>
              <div class="d-flex align-center gap-x-4 mb-2">
                <VAvatar
                  variant="tonal"
                  :color="card_color"
                  rounded="lg"
                >
                  <VIcon
                    :icon="card_icon_debt"
                    size="24"
                  />
                </VAvatar>
                <h4 class="text-h4">
                  {{ totalNonPatient }}
                </h4>
              </div>
              <div class="text-body-1 text-high-emphasis">
                Total Bukan Anggota
              </div>
            </VCardText>
          </VCard>
        </div>
      </VCol>
    </VRow>

    <!-- Data Table -->
    <VDataTable
      :headers="headers"
      :items="contentData"
      :search="search"
      :items-per-page="pagination.itemsPerPage"
      v-model:page="pagination.page"
      :page-count="pagination.totalPages"
      class="text-no-wrap"
    >
      <template v-slot:[`item.actions`]="{ item }">
        <div class="d-flex gap-1 justify-end">
          <IconBtn size="small" @click="itemDetail(item)">
            <VIcon icon="ri-information-line" title="Detail Transaction"/>
          </IconBtn>
        </div>
      </template>
      <!-- Pagination -->
      <template #bottom>
        <VDivider />
        <div class="d-flex justify-end flex-wrap gap-x-6 px-2 py-1">
          <div class="d-flex align-center gap-x-2 text-medium-emphasis text-base">
            Total Data: <b>{{ total_item }}</b> - Baris / Halaman:
            <VSelect
              v-model="pagination.itemsPerPage"
              class="per-page-select"
              variant="plain"
              :items="[10, 20, 25, 50, 100]"
            />
          </div>
          <div class="d-flex gap-x-2 align-center me-2">
            <VBtn
              class="flip-in-rtl"
              icon="ri-arrow-left-s-line"
              variant="text"
              density="comfortable"
              color="high-emphasis"
              @click="goToPreviousPage"
            />
            Halaman: <b>{{ value_page }}</b>
            <VBtn
              class="flip-in-rtl"
              icon="ri-arrow-right-s-line"
              density="comfortable"
              variant="text"
              color="high-emphasis"
              @click="goToNextPage"
            />
          </div>
        </div>
      </template>
    </VDataTable>
  </VRow>

  <VDialog v-model="historyPaymentDialog" max-width="1200px">
    <VCard :title="'Information Transaction'">
      <DialogCloseBtn variant="text" size="default" @click="closeDelete" />
      <VCardText>
        <VContainer>
          <VRow>
            <VCol cols="12" sm="6" md="3">
              <VTextField v-model="form_id" label="ID" readonly/>
            </VCol>
            <VCol cols="12" sm="6" md="3">
              <VTextField v-model="form_name" label="Name" readonly/>
            </VCol>
            <VCol cols="12" sm="6" md="3">
              <VTextField v-model="form_total_price" label="Total Price" readonly/>
            </VCol>
            <VCol cols="12" sm="6" md="3">
              <VTextField v-model="form_payment" label="Total Payment" readonly/>
            </VCol>
            <VCol cols="12" sm="12" md="12">
              <VTextField v-model="form_description" label="Description"  readonly/>
            </VCol>
          </VRow>

          <!-- Tombol Add Medicine -->
          <VRow>
            <VCol cols="12">
              <VBtn color="primary" variant="outlined">
                Detail Produk
              </VBtn>
            </VCol>
          </VRow>

          <!-- Daftar inputan dinamis untuk medicine -->
          <VRow v-for="(item, index) in itemDetails" :key="index" class="mt-4">
            <VCol cols="12" sm="4" md="4">
              <VTextField
                v-model="item.medicine"
                label="Produk"
                readonly
              />
            </VCol>
            <VCol cols="12" sm="2" md="3">
              <VTextField
                v-model="item.price"
                label="Price"
                readonly
              />
            </VCol>
            <VCol cols="12" sm="2" md="2">
              <VTextField
                v-model="item.qty"
                label="Qty"
                type="number"
                readonly
              />
            </VCol>
            <VCol cols="12" sm="2" md="3">
              <VTextField
                v-model="item.total"
                label="Total Price"
                readonly
              />
            </VCol>
          </VRow>
        
        </VContainer>
      </VCardText>
    </VCard>
  </VDialog>

</template>

<style lang="scss" scoped>
  @use "@core/scss/base/mixins" as mixins;

  .logistics-card-statistics {
    border-block-end-style: solid;
    border-block-end-width: 2px;
  }
</style>
