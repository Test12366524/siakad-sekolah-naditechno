<script setup lang="ts">
import { useRuntimeConfig } from "#app"; // Import useRuntimeConfig
import jsPDF from "jspdf";
import "jspdf-autotable";
import { onMounted, reactive, ref, watch } from "vue";
import { VRow, VTextarea } from "vuetify/lib/components/index.mjs";

const config = useRuntimeConfig();

// State for edit and delete confirmation dialogs
const contentData = ref([]);
const search = ref("");
const addDialog = ref(false);

const pagination = reactive({ page: 1, itemsPerPage: 10, totalPages: 0 });
let value_page = 1;
let total_item = 0;

const type = ref([
  { id: "cash", name: "Cash" },
  { id: "credit", name: "Hutang" },
  { id: "debit", name: "Debit" },
]);
const status_debit = ref();
const form_head_id = ref();
const form_user_id = ref();
const form_name = ref();
const form_type = ref("cash");
const form_bank_id = ref();
const form_description = ref();
const form_id = ref();
const form_medicine_id = ref("");
const form_medicine = ref("");
const form_price = ref(0);
const form_qty = ref(1);
const form_total_price = ref(0);

const itemDetails = ref([]);

// Headers for the table
const headers = [
  { title: "Product", key: "medicine", sortable: false },
  { title: "Price", key: "price", sortable: false },
  { title: "Stock", key: "stock", sortable: false },
  { title: "#", key: "actions", sortable: false, align: "end" },
];

const listBank = ref([]); // List of services
const fetchListBank = async () => {
  try {
    const response = await useApi("/master/bank/all");
    const data = response.data;
    listBank.value = [
      ...data.map((bank: any) => ({
        text: bank.name,
        value: bank.id,
      })),
    ];
  } catch (error) {
    console.error("Error fetching data:", error);
  }
};
// Function to fetch data from the API
const fetchData = async () => {
  try {
    const response = await fetch(
      `https://api-koperasi-express.sonisetiawan.my.id/api/transaction/form/listItem?page=${pagination.page}&itemsPerPage=${pagination.itemsPerPage}&search=${search.value}`
    );
    if (!response.ok) {
      throw new Error("Failed to fetch data");
    }
    const data = await response.json();
    contentData.value = data.items;
    total_item = data.totalItems;
    pagination.totalPages = data.totalPages;
  } catch (error) {
    console.error("Error fetching data:", error);
  }
};

const fetchID = async () => {
  try {
    const response = await fetch(
      `https://api-koperasi-express.sonisetiawan.my.id/api/transaction/form/getID`
    );
    if (!response.ok) {
      throw new Error("Failed to fetch data");
    }
    const data = await response.json();
    form_head_id.value = data;
  } catch (error) {
    console.error("Error fetching data:", error);
  }
};

const listUser = ref([]); // List of services
// list select
const fetchListUser = async () => {
  try {
    const response = await useApi("/user/all");
    const data = response.data;
    listUser.value = [
      ...data.map((user: any) => ({
        text: user.code + " - " + user.name,
        value: user.id,
      })),
    ];
  } catch (error) {
    console.error("Error fetching data:", error);
  }
};

// Fetch data when the component is mounted
onMounted(async () => {
  await Promise.all([fetchID(), fetchData(), fetchListUser(), fetchListBank()]);
});

// Polling function to check status every 5 seconds
let interval: number | null = null; // To store the interval ID

const checkStatusDebit = async () => {
  try {
    const response = await fetch(
      `https://api-koperasi-express.sonisetiawan.my.id/api/transaction/form/checkStatus?id=${form_head_id.value}`
    );
    const data = await response.json();
    // Assuming 'data.status' is the confirmation flag
    if (data.status === true) {
      alert("Transaksi berhasil");

      status_debit.value = "";
      await fetchID(); // Mengambil ID baru
      pagination.page = 1; // Reset ke halaman pertama setelah submit
      await fetchData();

      form_id.value = 0;
      form_medicine.value = "";
      form_medicine_id.value = "";
      form_name.value = "";
      form_bank_id.value = "";
      form_type.value = "";
      form_user_id.value = null;
      form_description.value = null;
      form_total_price.value = 0;
      form_qty.value = 1;
      itemDetails.value = [];

      fetchListUser();
      // Stop checking by clearing the interval
      if (interval) {
        clearInterval(interval);
        interval = null;
      }
    }
  } catch (error) {
    console.error("Error checking status:", error);
  }
};

// Start polling function for status debit
const startStatusPolling = () => {
  // Check every 5 seconds (5000 milliseconds)
  interval = setInterval(checkStatusDebit, 5000);
};

// Watch pagination or search changes to refetch data
watch(
  () => [pagination.itemsPerPage, search.value],
  () => {
    fetchData();
  }
);

const addItem = async (item: any) => {
  form_id.value = item.id;
  form_price.value = item.price;
  form_medicine_id.value = item.medicine_id;
  form_medicine.value = item.medicine;
  addDialog.value = true;
};

const close = () => {
  addDialog.value = false;
  resetForm();
};

const resetForm = () => {
  form_id.value = 0;
  form_medicine.value = "";
  form_medicine_id.value = "";
  form_qty.value = 1;
};

// Pagination functions
const goToNextPage = () => {
  if (pagination.page < pagination.totalPages) {
    value_page += 1;
    pagination.page = value_page;
    fetchData();
  }
};

const goToPreviousPage = () => {
  if (value_page > 1) {
    value_page -= 1;
    pagination.page = value_page;
    fetchData();
  }
};

// Add item to itemDetails array
const pushItem = () => {
  if (form_medicine.value && form_qty.value > 0) {
    // Log the form_id and existing item ids for debugging
    itemDetails.value.forEach((item) => console.log("item.id:", item.id));

    // Convert ids to the same type for comparison
    const idExists = itemDetails.value.some(
      (item) => item.id.toString() === form_id.value.toString()
    );

    if (!idExists) {
      // Calculate the total for this item (qty * price)
      let total = form_qty.value * form_price.value;

      // If id doesn't exist, push the new item without formatting the price or total
      itemDetails.value.push({
        medicine_id: form_medicine_id.value,
        medicine: form_medicine.value,
        qty: form_qty.value,
        price: form_price.value,
        total: total,
        id: form_id.value,
      });

      // Recalculate the overall total price
      const totalPrice = itemDetails.value.reduce((sum, item) => {
        return sum + item.price * item.qty;
      }, 0);

      // Format total price as Rupiah when displaying it
      form_total_price.value = totalPrice.toLocaleString("id-ID", {
        style: "currency",
        currency: "IDR",
        minimumFractionDigits: 0,
      });

      addDialog.value = false;
      resetForm();
    } else {
      alert("Item with this ID already exists.");
    }
  }
};

const printInvoice = () => {
  const transactionNumber = form_head_id.value;
  const user = listUser.value.find(
    (user) => user.value === form_user_id.value
  )?.text;
  const selectedType = type.value.find((t) => t.id === form_type.value)?.name;
  const selectedBank = listBank.value.find(
    (bank) => bank.value === form_bank_id.value
  )?.text;
  const totalPrice = form_total_price.value;

  //Setup Doc
  const doc = new jsPDF({
    format: [200, 100],
    unit: "mm",
  });
  const startingXPos = 10;
  const startingYPos = 10;
  const distanceHeader = 6;
  const generalDistane = 10;
  const pageWidth = doc.internal.pageSize.getWidth();
  const getCenterWidth = pageWidth / 2;

  //Setup Fonts
  const fontType = "helvetica";
  doc.setFont(fontType, "bold");

  //Header
  doc.setFontSize(14);
  doc.text("Khalisa Medic", getCenterWidth, startingYPos, {
    align: "center",
  });
  doc.setFont(fontType, "normal");
  doc.setFontSize(11);
  let nextYPos = startingYPos + distanceHeader;
  doc.text("tukangbikin.web.id@gmail.com", getCenterWidth, nextYPos, {
    align: "center",
  });
  nextYPos = nextYPos + distanceHeader;
  doc.text("+62 896-5248-3516", getCenterWidth, nextYPos, {
    align: "center",
  });

  //DIVIDER
  nextYPos = nextYPos + distanceHeader;
  doc.line(startingXPos, nextYPos, pageWidth - startingXPos, nextYPos);

  // DATE TIME
  nextYPos = nextYPos + distanceHeader + 3;
  doc.text(new Date().toLocaleDateString(), startingXPos, nextYPos);
  const time = new Date().toLocaleTimeString();
  doc.text(time, pageWidth + startingXPos - doc.getTextWidth(time), nextYPos, {
    align: "right",
  });

  // TRANSACTION NUMBER
  nextYPos = nextYPos + distanceHeader + 2;
  const xPosTransaction =
    pageWidth + startingXPos + 8 - doc.getTextWidth(transactionNumber);
  doc.text("No.Transaksi", startingXPos, nextYPos);
  doc.text(transactionNumber, xPosTransaction, nextYPos, {
    align: "right",
  });

  // PAYMENT TYPE
  nextYPos = nextYPos + distanceHeader + 2;
  const xPosPayment = pageWidth - doc.getTextWidth(form_type.value) - 2;
  doc.text("Pembayaran", startingXPos, nextYPos);
  doc.text(form_type.value, xPosPayment, nextYPos, {
    align: "right",
  });

  //DIVIDER
  nextYPos = nextYPos + distanceHeader;
  doc.line(startingXPos, nextYPos, pageWidth - startingXPos, nextYPos);

  // ITEM DETAILS
  doc.setFontSize(10);
  if (itemDetails.value.length > 0) {
    itemDetails.value.map((item, index) => {
      const offset = index === 0 ? distanceHeader + 2 : 12;
      nextYPos = nextYPos + offset;
      doc.setFont(fontType, "bold");
      doc.text(item.medicine, startingXPos, nextYPos);
      doc.setFont(fontType, "normal");
      doc.text(`${item.qty} + ${item.price}`, startingXPos, nextYPos + 5);
      doc.text(
        item.total.toString(),
        pageWidth - doc.getTextWidth(item.total.toString()),
        nextYPos,
        {
          align: "right",
        }
      );
      // doc.text(item.medicine_id, startingXPos + 100, nextYPos);
      // doc.text("Medicine", startingXPos + 100, nextYPos + distanceHeader);
    });
  }

  //DIVIDER
  nextYPos = nextYPos + distanceHeader + 5;
  doc.line(startingXPos, nextYPos, pageWidth - startingXPos, nextYPos);

  // TOTAL
  nextYPos = nextYPos + distanceHeader;
  doc.setFontSize(11);
  doc.setFont(fontType, "bold");
  doc.text("Total", startingXPos, nextYPos);
  doc.setFont(fontType, "normal");
  doc.text(
    totalPrice.toString(),
    pageWidth - doc.getTextWidth(totalPrice.toString()) + startingXPos,
    nextYPos,
    {
      align: "right",
    }
  );
  // Save the PDF
  doc.save("invoice.pdf");
};

const submitTransaction = async () => {
  printInvoice();
  // try {
  //   let status = 0;
  //   if (form_type.value === "debit" && form_user_id.value) {
  //     status_debit.value = "Menunggu konfirmasi";
  //     status = 0;

  //     startStatusPolling();
  //   } else {
  //     status = 1;
  //     status_debit.value = ""; // Reset status_debit jika tidak debit atau user_id tidak ada
  //   }

  //   if (form_type.value == "credit") {
  //     form_bank_id.value = 4;
  //   }

  //   const response = await fetch(
  //     `https://api-koperasi-express.sonisetiawan.my.id/api/transaction/form/submit`,
  //     {
  //       method: "POST",
  //       headers: {
  //         "Content-Type": "application/json",
  //       },
  //       body: JSON.stringify({
  //         id: form_head_id.value,
  //         user_id: form_user_id.value,
  //         name: form_name.value,
  //         description: form_description.value,
  //         total_price: form_total_price.value,
  //         bank_id: form_bank_id.value,
  //         type: form_type.value,
  //         status: status,
  //         created_by: "Soni",
  //         created_at: "2024-09-09 00:00:00",
  //         itemDetails: itemDetails.value,
  //       }),
  //     }
  //   );

  //   if (status !== 0) {
  //     await fetchID(); // Mengambil ID baru
  //     pagination.page = 1; // Reset ke halaman pertama setelah submit
  //     await fetchData();

  //     form_id.value = 0;
  //     form_medicine.value = "";
  //     form_medicine_id.value = "";
  //     form_name.value = "";
  //     form_bank_id.value = "";
  //     form_type.value = "";
  //     form_user_id.value = null;
  //     form_description.value = null;
  //     form_total_price.value = 0;
  //     form_qty.value = 1;
  //     itemDetails.value = [];

  //     fetchListUser();
  //   }
  // } catch (error) {
  //   console.error("Error adding item:", error);
  // }
};

const newOrder = async () => {
  try {
    status_debit.value = ""; // Reset status_debit jika tidak debit atau user_id tidak ada
    await fetchID(); // Mengambil ID baru
    pagination.page = 1; // Reset ke halaman pertama setelah submit
    await fetchData();

    form_id.value = 0;
    form_medicine.value = "";
    form_medicine_id.value = "";
    form_name.value = "";
    form_bank_id.value = "";
    form_type.value = "";
    form_user_id.value = null;
    form_description.value = null;
    form_total_price.value = 0;
    form_qty.value = 1;
    itemDetails.value = [];

    fetchListUser();
  } catch (error) {
    console.error("Error adding item:", error);
  }
};

// Remove item from the list
const removeItem = (index: number) => {
  itemDetails.value.splice(index, 1);
  const totalPrice = itemDetails.value.reduce((sum, item) => {
    return sum + item.price * item.qty;
  }, 0);
  form_total_price.value = totalPrice.toLocaleString("id-ID", {
    style: "currency",
    currency: "IDR",
    minimumFractionDigits: 0,
  });
};

const formatRupiah = (value: number) => {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    minimumFractionDigits: 0,
  }).format(value);
};

watch(form_type, (newType) => {
  if ((newType === "credit" || newType === "debit") && !form_user_id.value) {
    alert("Tipe kredit dan debit hanya diperbolehkan untuk anggota saja");
    form_type.value = "cash"; // Reset the type to 'cash'
  }
});
</script>

<template>
  <VRow>
    <!-- Data Table -->
    <VCol cols="12" md="7" sm="7">
      <VRow style="margin-block-end: 10px">
        <VCol cols="12" md="12" sm="12">
          <div>
            <VCard class="logistics-card-statistics cursor-pointer">
              <VCardText>
                <VRow>
                  <VCol cols="12" md="12" class="ms-md-auto">
                    <VTextField
                      v-model="search"
                      label="Search"
                      placeholder="Search ..."
                      append-inner-icon="ri-search-line"
                      single-line
                      hide-details
                      dense
                      outlined
                    />
                  </VCol>
                </VRow>
              </VCardText>
            </VCard>
          </div>
        </VCol>
      </VRow>
      <VDataTable
        :headers="headers"
        :items="contentData"
        :search="search"
        :items-per-page="pagination.itemsPerPage"
        v-model:page="pagination.page"
        :page-count="pagination.totalPages"
        class="text-no-wrap"
      >
        <template v-slot:[`item.price`]="{ item }">
          {{ formatRupiah(item.price) }}
        </template>
        <template v-slot:[`item.actions`]="{ item }">
          <div class="d-flex gap-1 justify-end">
            <VBtn
              title="Add Item"
              color="primary"
              variant="outlined"
              size="small"
              @click="addItem(item)"
            >
              Add Item
              <VIcon end icon="ri-add-circle-line" />
            </VBtn>
          </div>
        </template>

        <!-- Pagination -->
        <template #bottom>
          <VDivider />
          <div class="d-flex justify-end flex-wrap gap-x-6 px-2 py-1">
            <div
              class="d-flex align-center gap-x-2 text-medium-emphasis text-base"
            >
              Total Data: <b>{{ total_item }}</b> - Baris / Halaman:
              <VSelect
                v-model="pagination.itemsPerPage"
                class="per-page-select"
                variant="plain"
                :items="[10, 20, 25, 50, 100]"
              />
            </div>
            <div class="d-flex gap-x-2 align-center me-2">
              <VBtn
                class="flip-in-rtl"
                icon="ri-arrow-left-s-line"
                variant="text"
                density="comfortable"
                color="high-emphasis"
                @click="goToPreviousPage"
              />
              Halaman: <b>{{ value_page }}</b>
              <VBtn
                class="flip-in-rtl"
                icon="ri-arrow-right-s-line"
                density="comfortable"
                variant="text"
                color="high-emphasis"
                @click="goToNextPage"
              />
            </div>
          </div>
        </template>
      </VDataTable>
    </VCol>
    <VCol cols="12" md="5" sm="5">
      <VCard flat variant="outlined">
        <!-- 👉 payment offer -->
        <VCardText>
          <VRow>
            <VCol cols="12" sm="8" md="8">
              <h6 class="text-h6 mb-4">No. Transaction</h6>
            </VCol>
            <VCol cols="12" sm="4" md="4">
              <h6 class="text-h6 mb-4 text-right">
                {{ form_head_id }}
              </h6>
            </VCol>
          </VRow>

          <div class="d-flex align-center gap-4 flex-wrap">
            <VRow>
              <VCol cols="12" sm="6" md="6">
                <VAutocomplete
                  v-model="form_user_id"
                  label="Anggota"
                  density="compact"
                  placeholder="Pilih Anggota"
                  :items="listUser"
                  item-title="text"
                  item-value="value"
                  required
                />
              </VCol>
              <VCol cols="12" sm="1" md="1" style="margin-block-start: 10px">
                <span
                  style="font-size: 24px; inline-size: 100%; text-align: center"
                  >/</span
                >
              </VCol>
              <VCol cols="12" sm="5" md="5">
                <VTextField v-model="form_name" label="Name" />
              </VCol>
              <VCol cols="12" sm="6" md="6">
                <VSelect
                  v-model="form_type"
                  label="Tipe"
                  placeholder="Pilih Tipe"
                  :rules="[requiredValidator]"
                  :items="type"
                  item-value="id"
                  item-title="name"
                  clearable
                  clear-icon="ri-close-line"
                />
              </VCol>
              <VCol cols="12" sm="6" md="6">
                <VAutocomplete
                  v-model="form_bank_id"
                  label="Bank"
                  density="compact"
                  placeholder="Pilih Bank"
                  :rules="[requiredValidator]"
                  :items="listBank"
                  item-title="text"
                  item-value="value"
                  clearable
                  clear-icon="ri-close-line"
                />
              </VCol>
              <VCol cols="12" sm="12" md="12">
                <VTextarea
                  v-model="form_description"
                  label="Description"
                  rows="2"
                />
              </VCol>
            </VRow>
          </div>
        </VCardText>

        <VDivider />

        <!-- 👉 Price details -->
        <VCardText>
          <h6 class="text-h6 mb-4">Item Details</h6>

          <div v-if="itemDetails.length > 0" class="text-sm text-high-emphasis">
            <div
              v-for="(item, index) in itemDetails"
              :key="index"
              class="d-flex justify-space-between mb-2"
            >
              <div class="text-body-1 text-high-emphasis">
                {{ item.medicine }}
              </div>
              <div class="d-flex gap-x-4">
                <div class="text-body-1">
                  {{
                    item.price.toLocaleString({
                      style: "currency",
                      currency: "IDR",
                      minimumFractionDigits: 0,
                    })
                  }}
                </div>
                <div class="text-body-1 text-disabled">
                  x [{{ item.qty }}] =
                </div>
                <div class="text-body-1">
                  {{
                    item.total.toLocaleString({
                      style: "currency",
                      currency: "IDR",
                      minimumFractionDigits: 0,
                    })
                  }}
                </div>
                <IconBtn
                  size="small"
                  style="margin-block-start: -7px"
                  @click="removeItem(index)"
                >
                  <VIcon icon="ri-delete-bin-line" />
                </IconBtn>
              </div>
            </div>
          </div>

          <div v-else>
            <p>No items added yet.</p>
          </div>
        </VCardText>

        <VDivider />

        <VCardText class="d-flex justify-space-between">
          <h6 class="text-h6">Total</h6>
          <h6 class="text-h6">
            {{ form_total_price }}
          </h6>
        </VCardText>
        <VCardText
          class="d-flex justify-space-between"
          v-if="status_debit && status_debit.value !== ''"
        >
          <h6 class="text-h6">Status</h6>
          <h6 class="text-h6">{{ status_debit }}</h6>
        </VCardText>
      </VCard>

      <VBtn
        v-if="status_debit && status_debit.value !== ''"
        block
        class="mt-4"
        @click="newOrder"
      >
        Order Baru
      </VBtn>
      <VBtn block class="mt-4" @click="submitTransaction"> Submit </VBtn>
    </VCol>
  </VRow>

  <VDialog v-model="addDialog" max-width="600px">
    <VCard :title="'Add Item'">
      <DialogCloseBtn variant="text" size="default" @click="close" />

      <VCardText>
        <VContainer>
          <VRow>
            <VCol cols="12" sm="8" md="6">
              <VTextField v-model="form_medicine" label="Produk" readonly />
            </VCol>
            <VCol cols="12" sm="4" md="3">
              <VTextField type="number" v-model="form_qty" label="Qty" />
            </VCol>
            <VCol cols="12" sm="4" md="3">
              <VBtn
                variant="outlined"
                @click="pushItem"
                style="
                  block-size: 44px;
                  inline-size: 100%;
                  margin-block-start: 2px;
                "
              >
                Save&nbsp;&nbsp;&nbsp;
                <VIcon icon="ri-save-3-line" end class="flip-in-rtl" />
              </VBtn>
            </VCol>
          </VRow>
        </VContainer>
      </VCardText>
    </VCard>
  </VDialog>
</template>

<style lang="scss" scoped>
@use "@core/scss/base/mixins" as mixins;

.logistics-card-statistics {
  border-block-end-style: solid;
  border-block-end-width: 2px;
}
</style>
