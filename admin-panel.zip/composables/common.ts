export function useAppTable(conf: { path: string; limit?: number }) {
  const loading = ref(false);
  const limit = ref(conf.limit || 15);
  const total = ref(0);
  const currentPage = ref(1);
  const search = ref("");
  const items = ref();

  const { snackbar } = useCommonStore();

  async function removeRowBy(val: any) {
    const { success, message } = await useApi(`${conf.path}/${val}`, {
      withLoader: true,
      method: "DELETE",
    });

    snackbar.show({ message, color: success ? "info" : "error" });

    if (success) {
      fetchItems(true);
    }
  }

  async function fetchItems(reset?: boolean) {
    if (reset) {
      currentPage.value = 1;
    }

    loading.value = true;

    const { data, success, message } = await useApi(conf.path, {
      withLoader: false,
      params: {
        itemsPerPage: limit.value,
        limit: limit.value,
        page: currentPage.value,
        search: search.value,
      },
    });

    if (!success) {
      snackbar.show({ message, color: "error" });
    }

    loading.value = false;
    items.value = data.items ?? [];
    total.value = data.total;
  }

  return {
    limit,
    total,
    currentPage,
    search,
    items,
    loading,
    fetchItems,
    removeRowBy,
  };
}

export function getMenus() {
  const { menus } = useAuthStore();

  return menus;
}
