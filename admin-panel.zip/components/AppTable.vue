<script setup lang="ts">
import { VDataTableServer } from "vuetify/lib/components/index.mjs";

const props = defineProps({
  title: String,
  path: String,
  headers: Array<{
    title: String;
    key: String;
    sortable: null;
    width: null;
    rupiah?: Boolean;
  }>,
  withActions: null,
});

// Fungsi untuk format Rupiah
const formatRupiah = (value: number) => {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    minimumFractionDigits: 0,
  }).format(value);
};

const appTable = useAppTable({
  path: props.path as string,
});

defineExpose({
  refresh: () => appTable.fetchItems(true),
});
</script>

<template>
  <VCard>
    <VCardItem>
      <VRow align="center" justify="space-between">
        <VCol cols="12" md="8">
          <VCardTitle>{{ title }}</VCardTitle>
        </VCol>
        <VCol cols="12" md="4" class="d-flex align-center">
          <VTextField
            v-model="appTable.search.value"
            class="ma-2"
            density="compact"
            placeholder="Search..."
            hide-details
          ></VTextField>
        </VCol>
      </VRow>
    </VCardItem>

    <VDataTableServer
      fixed-header
      width="100%"
      :items-length="appTable.total.value"
      :items="appTable.items.value"
      v-model:page="appTable.currentPage.value"
      v-model:items-per-page="appTable.limit.value"
      :search="appTable.search.value"
      :loading="appTable.loading.value"
      loading-text="loading..."
      @update:options="() => appTable.fetchItems()"
      :headers="[
        ...(headers as any),
        withActions ? {
              title: 'actions',
              key: 'actions',
              sortable: false,
              width: 10,
            } : {},
      ] ?? []"
    >
      <template #item.jangka_waktu="{ item }">
        {{ item.jangka_waktu }} bulan
      </template>
      <template #item.zona_1="{ item }"> {{ item.zona_1 }} % </template>
      <template #item.zona_2="{ item }"> {{ item.zona_2 }} % </template>
      <template #item.zona_3="{ item }"> {{ item.zona_3 }} % </template>
      <template #item.zona_4="{ item }"> {{ item.zona_4 }} % </template>
      <template #item.usia="{ item }">
        {{ item.usia_from }} - {{ item.usia_to }}
      </template>
      <template #item.jumlah_menunggak="{ item }">
        {{ item.jumlah_menunggak }} hari
      </template>
      <template #item.rate_extra_premi="{ item }">
        {{ item.rate_extra_premi }}%
      </template>
      <template #item.support_kantor_pusat="{ item }">
        {{ item.support_kantor_pusat }}%
      </template>
      <template #item.simpanan_wajib="{ item }">
        {{ item.simpanan_wajib }}%
      </template>
      <template #item.simpanan_pokok="{ item }">
        {{ item.simpanan_pokok }}%
      </template>
      <template #item.cashback_percent="{ item }">
        {{ item.cashback_percent }}%
      </template>
      <template #item.interest_rate="{ item }">
        {{ item.interest_rate }}%
      </template>
      <template #item.nominal="{ item }">
        {{ formatRupiah(item.nominal) }}
      </template>
      <template #item.nominal_loan="{ item }">
        {{ formatRupiah(item.nominal_loan) }}
      </template>
      <template #item.remaining_payment="{ item }">
        {{ formatRupiah(item.remaining_payment) }}
      </template>
      <template #item.actions="{ item }">
        <slot name="actions" :item="item" :remove="appTable.removeRowBy"></slot>
      </template>
    </VDataTableServer>
  </VCard>
</template>
