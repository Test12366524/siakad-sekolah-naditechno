export default defineNuxtPlugin(() => {
  // This plugin just requires icons import
})
