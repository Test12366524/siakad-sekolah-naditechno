import { ensurePrefix } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/@antfu/utils/dist/index.mjs';

const getPublicUrl = (path) => {
  var _a;
  const baseUrl = (_a = process.env.NUXT_APP_BASE_URL) != null ? _a : "";
  const pathWithBaseUrl = `${baseUrl}${path}`;
  return `${ensurePrefix("/", pathWithBaseUrl)}`.replaceAll("//", "/");
};

export { getPublicUrl as g };
