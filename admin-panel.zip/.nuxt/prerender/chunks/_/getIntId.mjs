import { createError } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/h3/dist/index.mjs';

const getIntId = (event, msg404 = "Id is required to get item details") => {
  var _a;
  const id = Number((_a = event.context.params) == null ? void 0 : _a.id);
  if (!id || !Number.isInteger(id)) {
    throw createError({
      statusCode: 404,
      statusMessage: msg404
    });
  }
  return id;
};

export { getIntId as g };
