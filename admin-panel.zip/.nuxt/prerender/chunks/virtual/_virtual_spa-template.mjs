const template = "";

export { template };
