import { defineEventHandler, readBody, setResponseStatus } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/h3/dist/index.mjs';
import { d as db } from '../../../_/index2.mjs';

const genId = (array) => {
  var _a;
  const { length } = array;
  let lastIndex = 0;
  if (length)
    lastIndex = Number((_a = array[length - 1]) == null ? void 0 : _a.id) + 1;
  return lastIndex || length + 1;
};

const index_post = defineEventHandler(async (event) => {
  const eventToAdd = await readBody(event);
  db.events.push({
    ...eventToAdd,
    id: genId(db.events)
  });
  setResponseStatus(event, 201);
  return { body: eventToAdd };
});

export { index_post as default };
