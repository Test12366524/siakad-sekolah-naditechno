import { defineEventHandler } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/h3/dist/index.mjs';
import { d as database } from '../../../_/index7.mjs';
import '../../../_/getPublicUrl.mjs';
import 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/@antfu/utils/dist/index.mjs';

const index_get = defineEventHandler(() => {
  return database;
});

export { index_get as default };
