import { defineEventHandler, createError } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/h3/dist/index.mjs';
import { g as getIntId } from '../../../../_/getIntId.mjs';
import { d as database } from '../../../../_/index6.mjs';
import '../../../../_/getPublicUrl.mjs';
import 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/@antfu/utils/dist/index.mjs';

const _id__get = defineEventHandler((event) => {
  const invoiceId = getIntId(event, "User id is required to get user details");
  const id = Number(invoiceId);
  const invoice = database.find((e) => e.id === id);
  if (!invoice) {
    throw createError({
      statusCode: 404,
      statusMessage: "Invoice not found"
    });
  }
  return {
    invoice,
    paymentDetails: {
      totalDue: "$12,110.55",
      bankName: "American Bank",
      country: "United States",
      iban: "ETD95476213874685",
      swiftCode: "BR91905"
    }
  };
});

export { _id__get as default };
