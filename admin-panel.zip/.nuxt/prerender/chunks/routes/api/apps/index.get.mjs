import { defineEventHandler, getQuery, setResponseStatus } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/h3/dist/index.mjs';
import is from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/@sindresorhus/is/dist/index.js';
import { destr } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/destr/dist/index.mjs';
import { d as db } from '../../../_/index2.mjs';

const index_get = defineEventHandler((event) => {
  const queries = getQuery(event);
  const parsedCalendars = destr(queries.calendars);
  const calendars = is.array(parsedCalendars) ? parsedCalendars : parsedCalendars !== void 0 ? [parsedCalendars] : void 0;
  const events = db.events.filter((e) => calendars == null ? void 0 : calendars.includes(e.extendedProps.calendar));
  setResponseStatus(event, 200);
  return events;
});

export { index_get as default };
