import { getQuery } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/h3/dist/index.mjs';
import { p as paginateArray } from '../../../_/paginateArray.mjs';
import is from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/@sindresorhus/is/dist/index.js';
import { destr } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/destr/dist/index.mjs';
import { d as defineCachedEventHandler } from '../auth/_..._.mjs';
import 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/ofetch/dist/node.mjs';
import 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/unenv/runtime/fetch/index.mjs';
import 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/hookable/dist/index.mjs';
import 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/klona/dist/index.mjs';
import 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/scule/dist/index.mjs';
import 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/defu/dist/defu.mjs';
import 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/ohash/dist/index.mjs';
import 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/ufo/dist/index.mjs';
import 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/unstorage/dist/index.mjs';
import 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/unstorage/drivers/fs.mjs';
import 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/unstorage/drivers/memory.mjs';
import 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/unstorage/drivers/lru-cache.mjs';
import 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/unstorage/drivers/fs-lite.mjs';
import 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/radix3/dist/index.mjs';
import 'node:fs';
import 'node:url';
import 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/pathe/dist/index.mjs';

const db = {
  permissions: [
    {
      id: 1,
      name: "Management",
      assignedTo: ["administrator"],
      createdDate: "14 Apr 2021, 8:43 PM"
    },
    {
      id: 2,
      assignedTo: ["administrator"],
      name: "Manage Billing & Roles",
      createdDate: "16 Sep 2021, 5:20 PM"
    },
    {
      id: 3,
      name: "Add & Remove Users",
      createdDate: "14 Oct 2021, 10:20 AM",
      assignedTo: ["administrator", "manager"]
    },
    {
      id: 4,
      name: "Project Planning",
      createdDate: "14 Oct 2021, 10:20 AM",
      assignedTo: ["administrator", "users", "support"]
    },
    {
      id: 5,
      name: "Manage Email Sequences",
      createdDate: "23 Aug 2021, 2:00 PM",
      assignedTo: ["administrator", "users", "support"]
    },
    {
      id: 6,
      name: "Client Communication",
      createdDate: "15 Apr 2021, 11:30 AM",
      assignedTo: ["administrator", "manager"]
    },
    {
      id: 7,
      name: "Only View",
      createdDate: "04 Dec 2021, 8:15 PM",
      assignedTo: ["administrator", "restricted-user"]
    },
    {
      id: 8,
      name: "Financial Management",
      createdDate: "25 Feb 2021, 10:30 AM",
      assignedTo: ["administrator", "manager"]
    },
    {
      id: 9,
      name: "Manage Others' Tasks",
      createdDate: "04 Nov 2021, 11:45 AM",
      assignedTo: ["administrator", "support"]
    }
  ]
};

const index_get = defineCachedEventHandler((event) => {
  const { q = "", sortBy, page = 1, itemsPerPage = 10, orderBy } = getQuery(event);
  const parsedSortBy = destr(sortBy);
  const sortByLocal = is.string(parsedSortBy) ? parsedSortBy : "";
  const parsedOrderBy = destr(orderBy);
  const orderByLocal = is.string(parsedOrderBy) ? parsedOrderBy : "";
  const parsedItemsPerPage = destr(itemsPerPage);
  const parsedPage = destr(page);
  const itemsPerPageLocal = is.number(parsedItemsPerPage) ? parsedItemsPerPage : 10;
  const pageLocal = is.number(parsedPage) ? parsedPage : 1;
  const searchQuery = is.string(q) ? q : void 0;
  const queryLower = (searchQuery != null ? searchQuery : "").toString().toLowerCase();
  let filteredPermissions = db.permissions.filter(
    (permissions) => permissions.name.toLowerCase().includes(queryLower) || permissions.createdDate.toLowerCase().includes(queryLower) || permissions.assignedTo.some((i) => i.toLowerCase().startsWith(queryLower))
  );
  if (sortByLocal && sortByLocal === "name") {
    filteredPermissions = filteredPermissions.sort((a, b) => {
      if (orderByLocal === "asc")
        return a.name.localeCompare(b.name);
      return b.name.localeCompare(a.name);
    });
  }
  return { permissions: paginateArray(filteredPermissions, itemsPerPageLocal, pageLocal), totalPermissions: filteredPermissions.length };
});

export { index_get as default };
