import { defineEventHandler, getQuery, setResponseStatus } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/h3/dist/index.mjs';
import is from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/@sindresorhus/is/dist/index.js';
import { destr } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/destr/dist/index.mjs';
import { d as db } from '../../../../_/index.mjs';
import { p as paginateArray } from '../../../../_/paginateArray.mjs';
import '../../../../_/getPublicUrl.mjs';
import 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/@antfu/utils/dist/index.mjs';

const courses_get = defineEventHandler((event) => {
  const { q, hideCompleted, page = 1, itemsPerPage = 10, sortBy, orderBy, label = "All Courses" } = getQuery(event);
  const searchQuery = is.string(q) ? q : void 0;
  const queryLowered = (searchQuery != null ? searchQuery : "").toString().toLowerCase();
  const parsedHideCompleted = destr(hideCompleted);
  const hideCompletedLocal = is.boolean(parsedHideCompleted) ? parsedHideCompleted : false;
  const parsedSortBy = destr(sortBy);
  const sortByLocal = is.string(parsedSortBy) ? parsedSortBy : "";
  const parsedOrderBy = destr(orderBy);
  const orderByLocal = is.string(parsedOrderBy) ? parsedOrderBy : "";
  const parsedItemsPerPage = destr(itemsPerPage);
  const parsedPage = destr(page);
  const itemsPerPageLocal = is.number(parsedItemsPerPage) ? parsedItemsPerPage : 10;
  const pageLocal = is.number(parsedPage) ? parsedPage : 1;
  const parsedLabel = destr(label);
  const labelLocal = is.string(parsedLabel) ? parsedLabel : "All Courses";
  const filteredCourses = db.courses.filter((course) => {
    return (course.courseTitle.toLowerCase().includes(queryLowered) || course.user.toLowerCase().includes(queryLowered)) && !(course.completedTasks === course.totalTasks && hideCompletedLocal) && (labelLocal !== "All Courses" ? course.tags.toLocaleLowerCase() === (labelLocal == null ? void 0 : labelLocal.toLowerCase()) : true);
  });
  if (sortByLocal) {
    if (sortByLocal === "courseName") {
      filteredCourses.sort((a, b) => {
        if (orderByLocal === "asc")
          return a.courseTitle.localeCompare(b.courseTitle);
        else
          return b.courseTitle.localeCompare(a.courseTitle);
      });
    }
    if (sortByLocal === "progress") {
      filteredCourses.sort((a, b) => {
        if (orderByLocal === "asc")
          return a.completedTasks / a.totalTasks - b.completedTasks / b.totalTasks;
        else
          return b.completedTasks / b.totalTasks - a.completedTasks / a.totalTasks;
      });
    }
  }
  setResponseStatus(event, 200);
  return { courses: paginateArray(filteredCourses, itemsPerPageLocal, pageLocal), total: filteredCourses.length };
});

export { courses_get as default };
