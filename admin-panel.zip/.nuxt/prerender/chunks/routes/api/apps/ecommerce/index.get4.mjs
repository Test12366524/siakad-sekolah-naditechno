import { defineEventHandler, getQuery } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/h3/dist/index.mjs';
import is from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/@sindresorhus/is/dist/index.js';
import { destr } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/destr/dist/index.mjs';
import { d as db } from '../../../../_/index4.mjs';
import { p as paginateArray } from '../../../../_/paginateArray.mjs';
import '../../../../_/getPublicUrl.mjs';
import 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/@antfu/utils/dist/index.mjs';

const index_get = defineEventHandler((event) => {
  const { sortBy, itemsPerPage = 10, page = 1, orderBy } = getQuery(event);
  const parsedSortBy = destr(sortBy);
  const sortByLocal = is.string(parsedSortBy) ? parsedSortBy : "";
  const parsedOrderBy = destr(orderBy);
  const orderByLocal = is.string(parsedOrderBy) ? parsedOrderBy : "";
  const parsedItemsPerPage = destr(itemsPerPage);
  const parsedPage = destr(page);
  const itemsPerPageLocal = is.number(parsedItemsPerPage) ? parsedItemsPerPage : 10;
  const pageLocal = is.number(parsedPage) ? parsedPage : 1;
  const filteredReferrals = db.referrals;
  if (sortByLocal) {
    if (sortByLocal === "users") {
      filteredReferrals.sort((a, b) => {
        if (orderByLocal === "asc")
          return a.user.toLowerCase() > b.user.toLowerCase() ? 1 : -1;
        else if (orderByLocal === "desc")
          return a.user.toLowerCase() < b.user.toLowerCase() ? 1 : -1;
        return 0;
      });
    }
    if (sortByLocal === "referred-id") {
      filteredReferrals.sort((a, b) => {
        if (orderByLocal === "asc")
          return a.referredId - b.referredId;
        else if (orderByLocal === "desc")
          return b.referredId - a.referredId;
        return 0;
      });
    }
    if (sortByLocal === "earning") {
      filteredReferrals.sort((a, b) => {
        if (orderByLocal === "asc")
          return Number(a.earning.slice(1)) - Number(b.earning.slice(1));
        else if (orderByLocal === "desc")
          return Number(b.earning.slice(1)) - Number(a.earning.slice(1));
        return 0;
      });
    }
  }
  return { referrals: paginateArray(filteredReferrals, itemsPerPageLocal, pageLocal), total: filteredReferrals.length };
});

export { index_get as default };
