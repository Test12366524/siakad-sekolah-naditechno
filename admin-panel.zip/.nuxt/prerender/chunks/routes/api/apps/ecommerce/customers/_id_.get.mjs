import { defineEventHandler, setResponseStatus } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/h3/dist/index.mjs';
import { g as getIntId } from '../../../../../_/getIntId.mjs';
import { d as db } from '../../../../../_/index4.mjs';
import '../../../../../_/getPublicUrl.mjs';
import 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/@antfu/utils/dist/index.mjs';

const _id__get = defineEventHandler((event) => {
  const customerId = getIntId(event, "Customer id is required to get customer details");
  const id = Number(customerId);
  const customerIndex = db.customerData.findIndex((e) => e.customerId === id);
  const customer = db.customerData[customerIndex];
  Object.assign(customer, {
    status: "Active",
    contact: "+1 (234) 567 890"
  });
  if (customer)
    return customer;
  else
    setResponseStatus(event, 404);
});

export { _id__get as default };
