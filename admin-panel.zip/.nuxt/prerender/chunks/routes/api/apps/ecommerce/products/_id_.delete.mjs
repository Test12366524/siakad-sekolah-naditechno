import { defineEventHandler, setResponseStatus } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/h3/dist/index.mjs';
import { g as getIntId } from '../../../../../_/getIntId.mjs';
import { d as db } from '../../../../../_/index4.mjs';
import '../../../../../_/getPublicUrl.mjs';
import 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/@antfu/utils/dist/index.mjs';

const _id__delete = defineEventHandler((event) => {
  const productId = getIntId(event, "Product id is required to delete product");
  const id = Number(productId);
  const productIndex = db.products.findIndex((e) => e.id === id);
  if (productIndex >= 0) {
    db.products.splice(productIndex, 1);
    setResponseStatus(event, 204);
    return null;
  }
  setResponseStatus(event, 204);
});

export { _id__delete as default };
