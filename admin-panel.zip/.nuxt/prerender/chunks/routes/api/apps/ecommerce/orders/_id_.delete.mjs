import { defineEventHandler, setResponseStatus } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/h3/dist/index.mjs';
import { g as getIntId } from '../../../../../_/getIntId.mjs';
import { d as db } from '../../../../../_/index4.mjs';
import '../../../../../_/getPublicUrl.mjs';
import 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/@antfu/utils/dist/index.mjs';

const _id__delete = defineEventHandler((event) => {
  const orderId = getIntId(event, "Order id is required to get order details");
  const id = Number(orderId);
  const orderIndex = db.orderData.findIndex((e) => e.id === id);
  if (orderIndex >= 0) {
    db.orderData.splice(orderIndex, 1);
    setResponseStatus(event, 204);
    return null;
  }
  setResponseStatus(event, 204);
});

export { _id__delete as default };
