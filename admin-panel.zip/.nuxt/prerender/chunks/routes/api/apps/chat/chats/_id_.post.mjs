import { defineEventHandler, readBody, setResponseStatus } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/h3/dist/index.mjs';
import { g as getIntId } from '../../../../../_/getIntId.mjs';
import { d as db } from '../../../../../_/index3.mjs';
import '../../../../../_/getPublicUrl.mjs';
import 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/@antfu/utils/dist/index.mjs';

const _id__post = defineEventHandler(async (event) => {
  const chatId = getIntId(event, "Chat id is required to send message");
  const { message, senderId } = await readBody(event);
  let activeChat = db.chats.find((chat) => chat.userId === chatId);
  const newMessageData = {
    message,
    time: String(/* @__PURE__ */ new Date()),
    senderId,
    feedback: {
      isSent: true,
      isDelivered: false,
      isSeen: false
    }
  };
  let isNewChat = false;
  if (activeChat === void 0) {
    isNewChat = true;
    db.chats.push({
      id: db.chats.length + 1,
      userId: chatId,
      unseenMsgs: 0,
      messages: [newMessageData]
    });
    activeChat = db.chats.at(-1);
  } else {
    activeChat.messages.push(newMessageData);
  }
  const response = { msg: newMessageData };
  if (isNewChat)
    response.chat = activeChat;
  setResponseStatus(event, 201);
  return response;
});

export { _id__post as default };
