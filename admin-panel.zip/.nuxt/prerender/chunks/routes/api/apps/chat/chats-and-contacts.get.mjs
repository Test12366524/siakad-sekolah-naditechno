import { defineEventHandler, getQuery } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/h3/dist/index.mjs';
import { d as db } from '../../../../_/index3.mjs';
import '../../../../_/getPublicUrl.mjs';
import 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/@antfu/utils/dist/index.mjs';

const chatsAndContacts_get = defineEventHandler(async (event) => {
  const { q = "" } = getQuery(event);
  const qLowered = q.toLowerCase();
  const chatsContacts = db.chats.map((chat) => {
    const contact = JSON.parse(JSON.stringify(db.contacts.find((c) => c.id === chat.userId)));
    contact.chat = { id: chat.id, unseenMsgs: chat.unseenMsgs, lastMessage: chat.messages.at(-1) };
    return contact;
  }).reverse();
  const profileUserData = db.profileUser;
  return {
    chatsContacts: chatsContacts.filter((c) => c.fullName.toLowerCase().includes(qLowered)),
    contacts: db.contacts.filter((c) => c.fullName.toLowerCase().includes(qLowered)),
    profileUser: profileUserData
  };
});

export { chatsAndContacts_get as default };
