import { defineEventHandler } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/h3/dist/index.mjs';
import { g as getIntId } from '../../../../../_/getIntId.mjs';
import { d as db } from '../../../../../_/index3.mjs';
import '../../../../../_/getPublicUrl.mjs';
import 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/@antfu/utils/dist/index.mjs';

const _id__get = defineEventHandler(async (event) => {
  const userId = getIntId(event, "User id is required to get chat messages");
  const chat = db.chats.find((c) => c.userId === userId);
  if (chat)
    chat.unseenMsgs = 0;
  return {
    chat,
    contact: db.contacts.find((c) => c.id === userId)
  };
});

export { _id__get as default };
