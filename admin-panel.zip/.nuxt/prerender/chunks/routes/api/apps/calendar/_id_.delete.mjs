import { defineEventHandler, setResponseStatus } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/h3/dist/index.mjs';
import { g as getIntId } from '../../../../_/getIntId.mjs';
import { d as db } from '../../../../_/index2.mjs';

const _id__delete = defineEventHandler((event) => {
  const eventId = getIntId(event, "event Id is required to delete a event");
  const eventIndex = db.events.findIndex((e) => Number(e.id) === eventId);
  db.events.splice(eventIndex, 1);
  setResponseStatus(event, 204);
  return null;
});

export { _id__delete as default };
