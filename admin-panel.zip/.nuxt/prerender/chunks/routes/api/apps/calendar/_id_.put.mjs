import { defineEventHandler, readBody, setResponseStatus } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/h3/dist/index.mjs';
import { d as db } from '../../../../_/index2.mjs';

const _id__put = defineEventHandler(async (event) => {
  const updatedEvent = await readBody(event);
  updatedEvent.id = Number(updatedEvent.id);
  const currentEvent = db.events.find((e) => e.id === updatedEvent.id);
  if (currentEvent) {
    Object.assign(currentEvent, updatedEvent);
    setResponseStatus(event, 200);
    return currentEvent;
  }
  setResponseStatus(event, 400);
  return { message: "Something went wrong" };
});

export { _id__put as default };
