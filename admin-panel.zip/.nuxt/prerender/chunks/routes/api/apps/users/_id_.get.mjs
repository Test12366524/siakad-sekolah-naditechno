import { defineEventHandler, createError } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/h3/dist/index.mjs';
import { g as getIntId } from '../../../../_/getIntId.mjs';
import { d as db } from '../../../../_/index8.mjs';
import '../../../../_/getPublicUrl.mjs';
import 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/@antfu/utils/dist/index.mjs';

const _id__get = defineEventHandler((event) => {
  const userId = getIntId(event, "User id is required to get user details");
  const user = db.users.find((u) => u.id === userId);
  if (!user) {
    throw createError({
      statusCode: 404,
      statusMessage: "User not found"
    });
  }
  return {
    ...user,
    taskDone: 1230,
    projectDone: 568,
    taxId: "Tax-8894",
    language: "English"
  };
});

export { _id__get as default };
