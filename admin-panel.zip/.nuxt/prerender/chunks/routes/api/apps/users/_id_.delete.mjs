import { defineEventHandler, setResponseStatus } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/h3/dist/index.mjs';
import { g as getIntId } from '../../../../_/getIntId.mjs';
import { d as db } from '../../../../_/index8.mjs';
import '../../../../_/getPublicUrl.mjs';
import 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/@antfu/utils/dist/index.mjs';

const _id__delete = defineEventHandler((event) => {
  const userId = getIntId(event, "User id is required to delete a user");
  const userIndex = db.users.findIndex((user) => user.id === userId);
  db.users.splice(userIndex, 1);
  setResponseStatus(event, 204);
  return null;
});

export { _id__delete as default };
