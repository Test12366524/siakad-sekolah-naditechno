import { defineEventHandler, readBody, setResponseStatus } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/h3/dist/index.mjs';
import { destr } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/destr/dist/index.mjs';
import { d as db } from '../../../_/index5.mjs';
import '../../../_/getPublicUrl.mjs';
import 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/@antfu/utils/dist/index.mjs';

const index_post = defineEventHandler(async (event) => {
  const { ids: emailIds, data: dataToUpdate, label } = await readBody(event);
  const labelLocal = destr(label);
  if (!labelLocal) {
    let updateMailData = function(email) {
      Object.assign(email, dataToUpdate);
    };
    const emailIdsLocal = destr(emailIds);
    db.emails.forEach((email) => {
      if (emailIdsLocal.includes(email.id))
        updateMailData(email);
    });
    setResponseStatus(event, 200);
    return null;
  } else {
    let updateMailLabels = function(email) {
      const labelIndex = email.labels.indexOf(label);
      if (labelIndex === -1)
        email.labels.push(label);
      else
        email.labels.splice(labelIndex, 1);
    };
    db.emails.forEach((email) => {
      if (emailIds.includes(email.id))
        updateMailLabels(email);
    });
    setResponseStatus(event, 200);
    return null;
  }
});

export { index_post as default };
