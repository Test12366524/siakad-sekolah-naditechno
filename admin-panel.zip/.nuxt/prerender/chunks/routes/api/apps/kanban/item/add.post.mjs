import { defineEventHandler, readBody, setResponseStatus } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/h3/dist/index.mjs';
import { d as database } from '../../../../../_/index7.mjs';
import '../../../../../_/getPublicUrl.mjs';
import 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/@antfu/utils/dist/index.mjs';

const add_post = defineEventHandler(async (event) => {
  const { boardId, boardName, itemTitle } = await readBody(event);
  const itemId = database.items[database.items.length - 1].id + 1;
  if (itemTitle && boardName) {
    database.items.push({
      id: itemId,
      title: itemTitle,
      attachments: 0,
      comments: "",
      commentsCount: 0,
      dueDate: "",
      labels: [],
      members: []
    });
    const id = database.boards.findIndex((board) => board.id === boardId);
    database.boards[id].itemsIds.push(itemId);
  }
  setResponseStatus(event, 201);
});

export { add_post as default };
