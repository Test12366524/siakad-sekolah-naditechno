import { defineEventHandler, readBody } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/h3/dist/index.mjs';
import { d as database } from '../../../../../_/index7.mjs';
import '../../../../../_/getPublicUrl.mjs';
import 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/@antfu/utils/dist/index.mjs';

const stateUpdate_put = defineEventHandler(async (event) => {
  const boardState = await readBody(event);
  const sortedBoards = boardState.map((boardId) => {
    return database.boards.find((board) => board.id === boardId);
  });
  database.boards = sortedBoards;
});

export { stateUpdate_put as default };
