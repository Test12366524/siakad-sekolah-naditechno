import { defineEventHandler, readBody, setResponseStatus } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/h3/dist/index.mjs';
import { d as database } from '../../../../../_/index7.mjs';
import '../../../../../_/getPublicUrl.mjs';
import 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/@antfu/utils/dist/index.mjs';

const update_put = defineEventHandler(async (event) => {
  const { item: task } = await readBody(event);
  database.items.forEach((item) => {
    if (task && item.id === task.id) {
      item.title = task.title;
      item.attachments = task.attachments;
      item.comments = task.comments;
      item.commentsCount = task.commentsCount;
      item.dueDate = task.dueDate;
      item.labels = task.labels;
      item.members = task.members;
    }
  });
  setResponseStatus(event, 201);
});

export { update_put as default };
