import { defineEventHandler, setResponseStatus } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/h3/dist/index.mjs';
import { g as getIntId } from '../../../../../_/getIntId.mjs';
import { d as database } from '../../../../../_/index7.mjs';
import '../../../../../_/getPublicUrl.mjs';
import 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/@antfu/utils/dist/index.mjs';

const _id__delete = defineEventHandler(async (event) => {
  const boardId = getIntId(event, "User id is required to get board details");
  const boardIndex = database.boards.findIndex((board) => board.id === boardId);
  if (boardIndex === -1) {
    setResponseStatus(event, 404);
    return { body: { message: `Board with id ${boardId} not found` } };
  }
  database.boards.splice(boardIndex, 1);
  return { body: { message: `Board with id ${boardId} deleted` } };
});

export { _id__delete as default };
