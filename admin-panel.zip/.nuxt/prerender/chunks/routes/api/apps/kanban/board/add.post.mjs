import { defineEventHandler, readBody, setResponseStatus } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/h3/dist/index.mjs';
import { d as database } from '../../../../../_/index7.mjs';
import '../../../../../_/getPublicUrl.mjs';
import 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/@antfu/utils/dist/index.mjs';

const add_post = defineEventHandler(async (event) => {
  const { title } = await readBody(event);
  const getNewBoardId = () => {
    const newBoardId = database.boards.length + 1;
    if (!database.boards.some((board) => board.id === newBoardId))
      return newBoardId;
    else
      return newBoardId + 1;
  };
  if (database.boards.some((board) => board.title === title)) {
    setResponseStatus(event, 204);
  } else {
    database.boards.push({
      id: getNewBoardId(),
      title,
      itemsIds: []
    });
    setResponseStatus(event, 201);
  }
});

export { add_post as default };
