import process from 'node:process';globalThis._importMeta_=globalThis._importMeta_||{url:"file:///_entry.js",env:process.env};import { defineEventHandler, handleCacheHeaders, splitCookiesString, isEvent, createEvent, fetchWithEvent, getRequestHeader, eventHandler, setHeaders, sendRedirect, proxyRequest, setResponseStatus, setResponseHeader, send, getRequestHeaders, removeResponseHeader, createError, getResponseHeader, createApp, createRouter as createRouter$1, toNodeListener, lazyEventHandler } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/h3/dist/index.mjs';
import { createFetch as createFetch$1, Headers as Headers$1 } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/ofetch/dist/node.mjs';
import destr from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/destr/dist/index.mjs';
import { createCall, createFetch } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/unenv/runtime/fetch/index.mjs';
import { createHooks } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/hookable/dist/index.mjs';
import { klona } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/klona/dist/index.mjs';
import { snakeCase } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/scule/dist/index.mjs';
import defu, { defuFn } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/defu/dist/defu.mjs';
import { hash } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/ohash/dist/index.mjs';
import { parseURL, withoutBase, joinURL, getQuery, withQuery, decodePath, withLeadingSlash, withoutTrailingSlash } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/ufo/dist/index.mjs';
import { createStorage, prefixStorage } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/unstorage/dist/index.mjs';
import unstorage_47drivers_47fs from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/unstorage/drivers/fs.mjs';
import unstorage_47drivers_47memory from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/unstorage/drivers/memory.mjs';
import unstorage_47drivers_47lru_45cache from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/unstorage/drivers/lru-cache.mjs';
import unstorage_47drivers_47fs_45lite from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/unstorage/drivers/fs-lite.mjs';
import { toRouteMatcher, createRouter } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/radix3/dist/index.mjs';
import { promises } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/pathe/dist/index.mjs';

function getEnv(key, opts) {
  const envKey = snakeCase(key).toUpperCase();
  return destr(
    process.env[opts.prefix + envKey] ?? process.env[opts.altPrefix + envKey]
  );
}
function _isObject(input) {
  return typeof input === "object" && !Array.isArray(input);
}
function applyEnv(obj, opts, parentKey = "") {
  for (const key in obj) {
    const subKey = parentKey ? `${parentKey}_${key}` : key;
    const envValue = getEnv(subKey, opts);
    if (_isObject(obj[key])) {
      if (_isObject(envValue)) {
        obj[key] = { ...obj[key], ...envValue };
        applyEnv(obj[key], opts, subKey);
      } else if (envValue === void 0) {
        applyEnv(obj[key], opts, subKey);
      } else {
        obj[key] = envValue ?? obj[key];
      }
    } else {
      obj[key] = envValue ?? obj[key];
    }
    if (opts.envExpansion && typeof obj[key] === "string") {
      obj[key] = _expandFromEnv(obj[key]);
    }
  }
  return obj;
}
const envExpandRx = /{{(.*?)}}/g;
function _expandFromEnv(value) {
  return value.replace(envExpandRx, (match, key) => {
    return process.env[key] || match;
  });
}

const inlineAppConfig = {
  "nuxt": {
    "buildId": "dcd72308-03de-4d3c-a5fe-bd1a108c0f35"
  }
};



const appConfig = defuFn(inlineAppConfig);

const _inlineRuntimeConfig = {
  "app": {
    "baseURL": "/",
    "buildAssetsDir": "/_nuxt/",
    "cdnURL": ""
  },
  "nitro": {
    "envPrefix": "NUXT_",
    "routeRules": {
      "/__nuxt_error": {
        "cache": false
      },
      "/_nuxt/builds/meta/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      },
      "/_nuxt/builds/**": {
        "headers": {
          "cache-control": "public, max-age=1, immutable"
        }
      },
      "/_nuxt/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      }
    }
  },
  "public": {
    "apiBaseURL": "https://khalisamedic.web.id/api",
    "apiContentBaseURL": "https://api.khalisamedic.web.id",
    "websiteURL": "https://khalisamedic.web.id/",
    "device": {
      "enabled": true,
      "defaultUserAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.39 Safari/537.36",
      "refreshOnResize": false
    }
  },
  "AUTH_ORIGIN": "https://khalisamedic.web.id",
  "AUTH_SECRET": "7af82237c4ac5d172db8c53816139f2bf25236231130898bfebe65dace465d5e"
};
const envOptions = {
  prefix: "NITRO_",
  altPrefix: _inlineRuntimeConfig.nitro.envPrefix ?? process.env.NITRO_ENV_PREFIX ?? "_",
  envExpansion: _inlineRuntimeConfig.nitro.envExpansion ?? process.env.NITRO_ENV_EXPANSION ?? false
};
const _sharedRuntimeConfig = _deepFreeze(
  applyEnv(klona(_inlineRuntimeConfig), envOptions)
);
function useRuntimeConfig(event) {
  {
    return _sharedRuntimeConfig;
  }
}
_deepFreeze(klona(appConfig));
function _deepFreeze(object) {
  const propNames = Object.getOwnPropertyNames(object);
  for (const name of propNames) {
    const value = object[name];
    if (value && typeof value === "object") {
      _deepFreeze(value);
    }
  }
  return Object.freeze(object);
}
new Proxy(/* @__PURE__ */ Object.create(null), {
  get: (_, prop) => {
    console.warn(
      "Please use `useRuntimeConfig()` instead of accessing config directly."
    );
    const runtimeConfig = useRuntimeConfig();
    if (prop in runtimeConfig) {
      return runtimeConfig[prop];
    }
    return void 0;
  }
});

const serverAssets = [{"baseName":"server","dir":"C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/server/assets"}];

const assets$1 = createStorage();

for (const asset of serverAssets) {
  assets$1.mount(asset.baseName, unstorage_47drivers_47fs({ base: asset.dir }));
}

const storage = createStorage({});

storage.mount('/assets', assets$1);

storage.mount('internal:nuxt:prerender', unstorage_47drivers_47memory({"driver":"memory"}));
storage.mount('internal:nuxt:prerender:island', unstorage_47drivers_47lru_45cache({"driver":"lruCache","max":1000}));
storage.mount('internal:nuxt:prerender:payload', unstorage_47drivers_47lru_45cache({"driver":"lruCache","max":1000}));
storage.mount('data', unstorage_47drivers_47fs_45lite({"driver":"fsLite","base":"C:\\laragon\\www\\product-nuxt\\klinik-rsi\\admin-panel\\.data\\kv"}));
storage.mount('root', unstorage_47drivers_47fs({"driver":"fs","readOnly":true,"base":"C:\\laragon\\www\\product-nuxt\\klinik-rsi\\admin-panel","ignore":["**/node_modules/**","**/.git/**"]}));
storage.mount('src', unstorage_47drivers_47fs({"driver":"fs","readOnly":true,"base":"C:\\laragon\\www\\product-nuxt\\klinik-rsi\\admin-panel\\server","ignore":["**/node_modules/**","**/.git/**"]}));
storage.mount('build', unstorage_47drivers_47fs({"driver":"fs","readOnly":false,"base":"C:\\laragon\\www\\product-nuxt\\klinik-rsi\\admin-panel\\.nuxt","ignore":["**/node_modules/**","**/.git/**"]}));
storage.mount('cache', unstorage_47drivers_47fs({"driver":"fs","readOnly":false,"base":"C:\\laragon\\www\\product-nuxt\\klinik-rsi\\admin-panel\\.nuxt\\cache","ignore":["**/node_modules/**","**/.git/**"]}));

function useStorage(base = "") {
  return base ? prefixStorage(storage, base) : storage;
}

const defaultCacheOptions = {
  name: "_",
  base: "/cache",
  swr: true,
  maxAge: 1
};
function defineCachedFunction(fn, opts = {}) {
  opts = { ...defaultCacheOptions, ...opts };
  const pending = {};
  const group = opts.group || "nitro/functions";
  const name = opts.name || fn.name || "_";
  const integrity = opts.integrity || hash([fn, opts]);
  const validate = opts.validate || ((entry) => entry.value !== void 0);
  async function get(key, resolver, shouldInvalidateCache, event) {
    const cacheKey = [opts.base, group, name, key + ".json"].filter(Boolean).join(":").replace(/:\/$/, ":index");
    let entry = await useStorage().getItem(cacheKey) || {};
    if (typeof entry !== "object") {
      entry = {};
      const error = new Error("Malformed data read from cache.");
      console.error("[nitro] [cache]", error);
      useNitroApp().captureError(error, { event, tags: ["cache"] });
    }
    const ttl = (opts.maxAge ?? opts.maxAge ?? 0) * 1e3;
    if (ttl) {
      entry.expires = Date.now() + ttl;
    }
    const expired = shouldInvalidateCache || entry.integrity !== integrity || ttl && Date.now() - (entry.mtime || 0) > ttl || validate(entry) === false;
    const _resolve = async () => {
      const isPending = pending[key];
      if (!isPending) {
        if (entry.value !== void 0 && (opts.staleMaxAge || 0) >= 0 && opts.swr === false) {
          entry.value = void 0;
          entry.integrity = void 0;
          entry.mtime = void 0;
          entry.expires = void 0;
        }
        pending[key] = Promise.resolve(resolver());
      }
      try {
        entry.value = await pending[key];
      } catch (error) {
        if (!isPending) {
          delete pending[key];
        }
        throw error;
      }
      if (!isPending) {
        entry.mtime = Date.now();
        entry.integrity = integrity;
        delete pending[key];
        if (validate(entry) !== false) {
          const promise = useStorage().setItem(cacheKey, entry).catch((error) => {
            console.error(`[nitro] [cache] Cache write error.`, error);
            useNitroApp().captureError(error, { event, tags: ["cache"] });
          });
          if (event && event.waitUntil) {
            event.waitUntil(promise);
          }
        }
      }
    };
    const _resolvePromise = expired ? _resolve() : Promise.resolve();
    if (entry.value === void 0) {
      await _resolvePromise;
    } else if (expired && event && event.waitUntil) {
      event.waitUntil(_resolvePromise);
    }
    if (opts.swr && validate(entry) !== false) {
      _resolvePromise.catch((error) => {
        console.error(`[nitro] [cache] SWR handler error.`, error);
        useNitroApp().captureError(error, { event, tags: ["cache"] });
      });
      return entry;
    }
    return _resolvePromise.then(() => entry);
  }
  return async (...args) => {
    const shouldBypassCache = await opts.shouldBypassCache?.(...args);
    if (shouldBypassCache) {
      return fn(...args);
    }
    const key = await (opts.getKey || getKey)(...args);
    const shouldInvalidateCache = await opts.shouldInvalidateCache?.(...args);
    const entry = await get(
      key,
      () => fn(...args),
      shouldInvalidateCache,
      args[0] && isEvent(args[0]) ? args[0] : void 0
    );
    let value = entry.value;
    if (opts.transform) {
      value = await opts.transform(entry, ...args) || value;
    }
    return value;
  };
}
const cachedFunction = defineCachedFunction;
function getKey(...args) {
  return args.length > 0 ? hash(args, {}) : "";
}
function escapeKey(key) {
  return String(key).replace(/\W/g, "");
}
function defineCachedEventHandler(handler, opts = defaultCacheOptions) {
  const variableHeaderNames = (opts.varies || []).filter(Boolean).map((h) => h.toLowerCase()).sort();
  const _opts = {
    ...opts,
    getKey: async (event) => {
      const customKey = await opts.getKey?.(event);
      if (customKey) {
        return escapeKey(customKey);
      }
      const _path = event.node.req.originalUrl || event.node.req.url || event.path;
      const _pathname = escapeKey(decodeURI(parseURL(_path).pathname)).slice(0, 16) || "index";
      const _hashedPath = `${_pathname}.${hash(_path)}`;
      const _headers = variableHeaderNames.map((header) => [header, event.node.req.headers[header]]).map(([name, value]) => `${escapeKey(name)}.${hash(value)}`);
      return [_hashedPath, ..._headers].join(":");
    },
    validate: (entry) => {
      if (!entry.value) {
        return false;
      }
      if (entry.value.code >= 400) {
        return false;
      }
      if (entry.value.body === void 0) {
        return false;
      }
      if (entry.value.headers.etag === "undefined" || entry.value.headers["last-modified"] === "undefined") {
        return false;
      }
      return true;
    },
    group: opts.group || "nitro/handlers",
    integrity: opts.integrity || hash([handler, opts])
  };
  const _cachedHandler = cachedFunction(
    async (incomingEvent) => {
      const variableHeaders = {};
      for (const header of variableHeaderNames) {
        variableHeaders[header] = incomingEvent.node.req.headers[header];
      }
      const reqProxy = cloneWithProxy(incomingEvent.node.req, {
        headers: variableHeaders
      });
      const resHeaders = {};
      let _resSendBody;
      const resProxy = cloneWithProxy(incomingEvent.node.res, {
        statusCode: 200,
        writableEnded: false,
        writableFinished: false,
        headersSent: false,
        closed: false,
        getHeader(name) {
          return resHeaders[name];
        },
        setHeader(name, value) {
          resHeaders[name] = value;
          return this;
        },
        getHeaderNames() {
          return Object.keys(resHeaders);
        },
        hasHeader(name) {
          return name in resHeaders;
        },
        removeHeader(name) {
          delete resHeaders[name];
        },
        getHeaders() {
          return resHeaders;
        },
        end(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        write(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        writeHead(statusCode, headers2) {
          this.statusCode = statusCode;
          if (headers2) {
            for (const header in headers2) {
              this.setHeader(header, headers2[header]);
            }
          }
          return this;
        }
      });
      const event = createEvent(reqProxy, resProxy);
      event.fetch = (url, fetchOptions) => fetchWithEvent(event, url, fetchOptions, {
        fetch: useNitroApp().localFetch
      });
      event.$fetch = (url, fetchOptions) => fetchWithEvent(event, url, fetchOptions, {
        fetch: globalThis.$fetch
      });
      event.context = incomingEvent.context;
      event.context.cache = {
        options: _opts
      };
      const body = await handler(event) || _resSendBody;
      const headers = event.node.res.getHeaders();
      headers.etag = String(
        headers.Etag || headers.etag || `W/"${hash(body)}"`
      );
      headers["last-modified"] = String(
        headers["Last-Modified"] || headers["last-modified"] || (/* @__PURE__ */ new Date()).toUTCString()
      );
      const cacheControl = [];
      if (opts.swr) {
        if (opts.maxAge) {
          cacheControl.push(`s-maxage=${opts.maxAge}`);
        }
        if (opts.staleMaxAge) {
          cacheControl.push(`stale-while-revalidate=${opts.staleMaxAge}`);
        } else {
          cacheControl.push("stale-while-revalidate");
        }
      } else if (opts.maxAge) {
        cacheControl.push(`max-age=${opts.maxAge}`);
      }
      if (cacheControl.length > 0) {
        headers["cache-control"] = cacheControl.join(", ");
      }
      const cacheEntry = {
        code: event.node.res.statusCode,
        headers,
        body
      };
      return cacheEntry;
    },
    _opts
  );
  return defineEventHandler(async (event) => {
    if (opts.headersOnly) {
      if (handleCacheHeaders(event, { maxAge: opts.maxAge })) {
        return;
      }
      return handler(event);
    }
    const response = await _cachedHandler(event);
    if (event.node.res.headersSent || event.node.res.writableEnded) {
      return response.body;
    }
    if (handleCacheHeaders(event, {
      modifiedTime: new Date(response.headers["last-modified"]),
      etag: response.headers.etag,
      maxAge: opts.maxAge
    })) {
      return;
    }
    event.node.res.statusCode = response.code;
    for (const name in response.headers) {
      const value = response.headers[name];
      if (name === "set-cookie") {
        event.node.res.appendHeader(
          name,
          splitCookiesString(value)
        );
      } else {
        event.node.res.setHeader(name, value);
      }
    }
    return response.body;
  });
}
function cloneWithProxy(obj, overrides) {
  return new Proxy(obj, {
    get(target, property, receiver) {
      if (property in overrides) {
        return overrides[property];
      }
      return Reflect.get(target, property, receiver);
    },
    set(target, property, value, receiver) {
      if (property in overrides) {
        overrides[property] = value;
        return true;
      }
      return Reflect.set(target, property, value, receiver);
    }
  });
}
const cachedEventHandler = defineCachedEventHandler;

function hasReqHeader(event, name, includes) {
  const value = getRequestHeader(event, name);
  return value && typeof value === "string" && value.toLowerCase().includes(includes);
}
function isJsonRequest(event) {
  if (hasReqHeader(event, "accept", "text/html")) {
    return false;
  }
  return hasReqHeader(event, "accept", "application/json") || hasReqHeader(event, "user-agent", "curl/") || hasReqHeader(event, "user-agent", "httpie/") || hasReqHeader(event, "sec-fetch-mode", "cors") || event.path.startsWith("/api/") || event.path.endsWith(".json");
}
function normalizeError(error) {
  const cwd = typeof process.cwd === "function" ? process.cwd() : "/";
  const stack = (error.stack || "").split("\n").splice(1).filter((line) => line.includes("at ")).map((line) => {
    const text = line.replace(cwd + "/", "./").replace("webpack:/", "").replace("file://", "").trim();
    return {
      text,
      internal: line.includes("node_modules") && !line.includes(".cache") || line.includes("internal") || line.includes("new Promise")
    };
  });
  const statusCode = error.statusCode || 500;
  const statusMessage = error.statusMessage ?? (statusCode === 404 ? "Not Found" : "");
  const message = error.message || error.toString();
  return {
    stack,
    statusCode,
    statusMessage,
    message
  };
}
function _captureError(error, type) {
  console.error(`[nitro] [${type}]`, error);
  useNitroApp().captureError(error, { tags: [type] });
}
function trapUnhandledNodeErrors() {
  process.on(
    "unhandledRejection",
    (error) => _captureError(error, "unhandledRejection")
  );
  process.on(
    "uncaughtException",
    (error) => _captureError(error, "uncaughtException")
  );
}
function joinHeaders(value) {
  return Array.isArray(value) ? value.join(", ") : String(value);
}
function normalizeFetchResponse(response) {
  if (!response.headers.has("set-cookie")) {
    return response;
  }
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers: normalizeCookieHeaders(response.headers)
  });
}
function normalizeCookieHeader(header = "") {
  return splitCookiesString(joinHeaders(header));
}
function normalizeCookieHeaders(headers) {
  const outgoingHeaders = new Headers();
  for (const [name, header] of headers) {
    if (name === "set-cookie") {
      for (const cookie of normalizeCookieHeader(header)) {
        outgoingHeaders.append("set-cookie", cookie);
      }
    } else {
      outgoingHeaders.set(name, joinHeaders(header));
    }
  }
  return outgoingHeaders;
}

const config = useRuntimeConfig();
const _routeRulesMatcher = toRouteMatcher(
  createRouter({ routes: config.nitro.routeRules })
);
function createRouteRulesHandler(ctx) {
  return eventHandler((event) => {
    const routeRules = getRouteRules(event);
    if (routeRules.headers) {
      setHeaders(event, routeRules.headers);
    }
    if (routeRules.redirect) {
      let target = routeRules.redirect.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.redirect._redirectStripBase;
        if (strpBase) {
          targetPath = withoutBase(targetPath, strpBase);
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery(event.path);
        target = withQuery(target, query);
      }
      return sendRedirect(event, target, routeRules.redirect.statusCode);
    }
    if (routeRules.proxy) {
      let target = routeRules.proxy.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.proxy._proxyStripBase;
        if (strpBase) {
          targetPath = withoutBase(targetPath, strpBase);
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery(event.path);
        target = withQuery(target, query);
      }
      return proxyRequest(event, target, {
        fetch: ctx.localFetch,
        ...routeRules.proxy
      });
    }
  });
}
function getRouteRules(event) {
  event.context._nitro = event.context._nitro || {};
  if (!event.context._nitro.routeRules) {
    event.context._nitro.routeRules = getRouteRulesForPath(
      withoutBase(event.path.split("?")[0], useRuntimeConfig().app.baseURL)
    );
  }
  return event.context._nitro.routeRules;
}
function getRouteRulesForPath(path) {
  return defu({}, ..._routeRulesMatcher.matchAll(path).reverse());
}

function defineNitroPlugin(def) {
  return def;
}

const _EI7qC8hl3G = defineNitroPlugin((nitroApp) => {
  nitroApp.hooks.hook("render:response", (response) => {
    response.body = response.body.replaceAll("/_nuxt/\0", "/_nuxt/");
  });
});

const plugins = [
  _EI7qC8hl3G
];

const errorHandler = (async function errorhandler(error, event) {
  const { stack, statusCode, statusMessage, message } = normalizeError(error);
  const errorObject = {
    url: event.path,
    statusCode,
    statusMessage,
    message,
    stack: "",
    // TODO: check and validate error.data for serialisation into query
    data: error.data
  };
  if (error.unhandled || error.fatal) {
    const tags = [
      "[nuxt]",
      "[request error]",
      error.unhandled && "[unhandled]",
      error.fatal && "[fatal]",
      Number(errorObject.statusCode) !== 200 && `[${errorObject.statusCode}]`
    ].filter(Boolean).join(" ");
    console.error(tags, errorObject.message + "\n" + stack.map((l) => "  " + l.text).join("  \n"));
  }
  if (event.handled) {
    return;
  }
  setResponseStatus(event, errorObject.statusCode !== 200 && errorObject.statusCode || 500, errorObject.statusMessage);
  if (isJsonRequest(event)) {
    setResponseHeader(event, "Content-Type", "application/json");
    return send(event, JSON.stringify(errorObject));
  }
  const reqHeaders = getRequestHeaders(event);
  const isRenderingError = event.path.startsWith("/__nuxt_error") || !!reqHeaders["x-nuxt-error"];
  const res = isRenderingError ? null : await useNitroApp().localFetch(
    withQuery(joinURL(useRuntimeConfig().app.baseURL, "/__nuxt_error"), errorObject),
    {
      headers: { ...reqHeaders, "x-nuxt-error": "true" },
      redirect: "manual"
    }
  ).catch(() => null);
  if (!res) {
    const { template } = await import('../../../_/error-500.mjs');
    if (event.handled) {
      return;
    }
    setResponseHeader(event, "Content-Type", "text/html;charset=UTF-8");
    return send(event, template(errorObject));
  }
  const html = await res.text();
  if (event.handled) {
    return;
  }
  for (const [header, value] of res.headers.entries()) {
    setResponseHeader(event, header, value);
  }
  setResponseStatus(event, res.status && res.status !== 200 ? res.status : void 0, res.statusText);
  return send(event, html);
});

const assets = {};

function readAsset (id) {
  const serverDir = dirname(fileURLToPath(globalThis._importMeta_.url));
  return promises.readFile(resolve(serverDir, assets[id].path))
}

const publicAssetBases = {"/_nuxt/builds/meta/":{"maxAge":31536000},"/_nuxt/builds/":{"maxAge":1},"/_nuxt/":{"maxAge":31536000}};

function isPublicAssetURL(id = '') {
  if (assets[id]) {
    return true
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) { return true }
  }
  return false
}

function getAsset (id) {
  return assets[id]
}

const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = { gzip: ".gz", br: ".br" };
const _f4b49z = eventHandler((event) => {
  if (event.method && !METHODS.has(event.method)) {
    return;
  }
  let id = decodePath(
    withLeadingSlash(withoutTrailingSlash(parseURL(event.path).pathname))
  );
  let asset;
  const encodingHeader = String(
    getRequestHeader(event, "accept-encoding") || ""
  );
  const encodings = [
    ...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(),
    ""
  ];
  if (encodings.length > 1) {
    setResponseHeader(event, "Vary", "Accept-Encoding");
  }
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      removeResponseHeader(event, "Cache-Control");
      throw createError({
        statusMessage: "Cannot find static asset " + id,
        statusCode: 404
      });
    }
    return;
  }
  const ifNotMatch = getRequestHeader(event, "if-none-match") === asset.etag;
  if (ifNotMatch) {
    setResponseStatus(event, 304, "Not Modified");
    return "";
  }
  const ifModifiedSinceH = getRequestHeader(event, "if-modified-since");
  const mtimeDate = new Date(asset.mtime);
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
    setResponseStatus(event, 304, "Not Modified");
    return "";
  }
  if (asset.type && !getResponseHeader(event, "Content-Type")) {
    setResponseHeader(event, "Content-Type", asset.type);
  }
  if (asset.etag && !getResponseHeader(event, "ETag")) {
    setResponseHeader(event, "ETag", asset.etag);
  }
  if (asset.mtime && !getResponseHeader(event, "Last-Modified")) {
    setResponseHeader(event, "Last-Modified", mtimeDate.toUTCString());
  }
  if (asset.encoding && !getResponseHeader(event, "Content-Encoding")) {
    setResponseHeader(event, "Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !getResponseHeader(event, "Content-Length")) {
    setResponseHeader(event, "Content-Length", asset.size);
  }
  return readAsset(id);
});

const _lazy_L7T6Nz = () => import('../app-bar/index.mjs');
const _lazy_XPwDcV = () => import('../apps/academy/course-details.get.mjs');
const _lazy_DoyBuO = () => import('../apps/academy/courses.get.mjs');
const _lazy_gyOm05 = () => import('../apps/calendar/_id_.delete.mjs');
const _lazy_aec8UP = () => import('../apps/calendar/_id_.put.mjs');
const _lazy_1ADy3e = () => import('../apps/index.get.mjs');
const _lazy_WG33xZ = () => import('../apps/index.post3.mjs');
const _lazy_PEcwHx = () => import('../apps/chat/chats-and-contacts.get.mjs');
const _lazy_tBwU8W = () => import('../apps/chat/chats/_id_.get.mjs');
const _lazy_FYBWBa = () => import('../apps/chat/chats/_id_.post.mjs');
const _lazy_Pvo5v4 = () => import('../apps/ecommerce/customers/_id_.get.mjs');
const _lazy_ZuMzrs = () => import('../apps/ecommerce/index.get.mjs');
const _lazy_UNq9Gr = () => import('../apps/ecommerce/orders/_id_.delete.mjs');
const _lazy_4anWiz = () => import('../apps/ecommerce/index.get2.mjs');
const _lazy_NKHpa9 = () => import('../apps/ecommerce/products/_id_.delete.mjs');
const _lazy_eXiRLH = () => import('../apps/ecommerce/index.get3.mjs');
const _lazy_n6NTPq = () => import('../apps/ecommerce/index.get4.mjs');
const _lazy_VYFfA1 = () => import('../apps/ecommerce/reviews/_id_.delete.mjs');
const _lazy_kdYZWi = () => import('../apps/ecommerce/index.get5.mjs');
const _lazy_nmhWNT = () => import('../apps/index.get2.mjs');
const _lazy_ev9lxo = () => import('../apps/index.post.mjs');
const _lazy_XlhFkF = () => import('../apps/invoice/_id_.delete.mjs');
const _lazy_Pus4bM = () => import('../apps/invoice/_id_.get.mjs');
const _lazy_sxIwv1 = () => import('../apps/invoice/clients.get.mjs');
const _lazy_z1OkoZ = () => import('../apps/index.get3.mjs');
const _lazy_I4NhwH = () => import('../apps/kanban/board/_id_.delete.mjs');
const _lazy_iWmhNy = () => import('../apps/kanban/board/add.post.mjs');
const _lazy_RaOlXB = () => import('../apps/kanban/board/rename.put.mjs');
const _lazy_jLYBIl = () => import('../apps/kanban/board/state-update.put.mjs');
const _lazy_mrw4gS = () => import('../apps/index.get4.mjs');
const _lazy_LBFthB = () => import('../apps/kanban/item/_id_.delete.mjs');
const _lazy_aXLXrn = () => import('../apps/kanban/item/add.post.mjs');
const _lazy_OHINfi = () => import('../apps/kanban/item/state-update.put.mjs');
const _lazy_vo6S1Q = () => import('../apps/kanban/item/update.put.mjs');
const _lazy_z0anJq = () => import('../apps/logistics/index.mjs');
const _lazy_kATGQP = () => import('../apps/index.get6.mjs');
const _lazy_IbXmnN = () => import('../apps/users/_id_.delete.mjs');
const _lazy_K474JG = () => import('../apps/users/_id_.get.mjs');
const _lazy_ov2ZFu = () => import('../apps/index.get5.mjs');
const _lazy_GXX4LO = () => import('../apps/index.post2.mjs');
const _lazy_5xPTtA = () => Promise.resolve().then(function () { return _____; });
const _lazy_rz4X9a = () => import('../pages/datatable.get.mjs');
const _lazy_khpwWV = () => import('../pages/faq.get.mjs');
const _lazy_oeHdbm = () => import('../pages/help-center/index.get.mjs');
const _lazy_eNxXsa = () => import('../pages/index.get.mjs');
const _lazy_wzYTug = () => import('../pages/profile/header.get.mjs');
const _lazy_IbOeYc = () => import('../pages/index.get2.mjs');
const _lazy_gbM3Ht = () => import('../../../_/renderer.mjs').then(function (n) { return n.r; });

const handlers = [
  { route: '', handler: _f4b49z, lazy: false, middleware: true, method: undefined },
  { route: '/api/app-bar/search', handler: _lazy_L7T6Nz, lazy: true, middleware: false, method: undefined },
  { route: '/api/apps/academy/course-details', handler: _lazy_XPwDcV, lazy: true, middleware: false, method: "get" },
  { route: '/api/apps/academy/courses', handler: _lazy_DoyBuO, lazy: true, middleware: false, method: "get" },
  { route: '/api/apps/calendar/:id', handler: _lazy_gyOm05, lazy: true, middleware: false, method: "delete" },
  { route: '/api/apps/calendar/:id', handler: _lazy_aec8UP, lazy: true, middleware: false, method: "put" },
  { route: '/api/apps/calendar', handler: _lazy_1ADy3e, lazy: true, middleware: false, method: "get" },
  { route: '/api/apps/calendar', handler: _lazy_WG33xZ, lazy: true, middleware: false, method: "post" },
  { route: '/api/apps/chat/chats-and-contacts', handler: _lazy_PEcwHx, lazy: true, middleware: false, method: "get" },
  { route: '/api/apps/chat/chats/:id', handler: _lazy_tBwU8W, lazy: true, middleware: false, method: "get" },
  { route: '/api/apps/chat/chats/:id', handler: _lazy_FYBWBa, lazy: true, middleware: false, method: "post" },
  { route: '/api/apps/ecommerce/customers/:id', handler: _lazy_Pvo5v4, lazy: true, middleware: false, method: "get" },
  { route: '/api/apps/ecommerce/customers', handler: _lazy_ZuMzrs, lazy: true, middleware: false, method: "get" },
  { route: '/api/apps/ecommerce/orders/:id', handler: _lazy_UNq9Gr, lazy: true, middleware: false, method: "delete" },
  { route: '/api/apps/ecommerce/orders', handler: _lazy_4anWiz, lazy: true, middleware: false, method: "get" },
  { route: '/api/apps/ecommerce/products/:id', handler: _lazy_NKHpa9, lazy: true, middleware: false, method: "delete" },
  { route: '/api/apps/ecommerce/products', handler: _lazy_eXiRLH, lazy: true, middleware: false, method: "get" },
  { route: '/api/apps/ecommerce/referrals', handler: _lazy_n6NTPq, lazy: true, middleware: false, method: "get" },
  { route: '/api/apps/ecommerce/reviews/:id', handler: _lazy_VYFfA1, lazy: true, middleware: false, method: "delete" },
  { route: '/api/apps/ecommerce/reviews', handler: _lazy_kdYZWi, lazy: true, middleware: false, method: "get" },
  { route: '/api/apps/email', handler: _lazy_nmhWNT, lazy: true, middleware: false, method: "get" },
  { route: '/api/apps/email', handler: _lazy_ev9lxo, lazy: true, middleware: false, method: "post" },
  { route: '/api/apps/invoice/:id', handler: _lazy_XlhFkF, lazy: true, middleware: false, method: "delete" },
  { route: '/api/apps/invoice/:id', handler: _lazy_Pus4bM, lazy: true, middleware: false, method: "get" },
  { route: '/api/apps/invoice/clients', handler: _lazy_sxIwv1, lazy: true, middleware: false, method: "get" },
  { route: '/api/apps/invoice', handler: _lazy_z1OkoZ, lazy: true, middleware: false, method: "get" },
  { route: '/api/apps/kanban/board/:id', handler: _lazy_I4NhwH, lazy: true, middleware: false, method: "delete" },
  { route: '/api/apps/kanban/board/add', handler: _lazy_iWmhNy, lazy: true, middleware: false, method: "post" },
  { route: '/api/apps/kanban/board/rename', handler: _lazy_RaOlXB, lazy: true, middleware: false, method: "put" },
  { route: '/api/apps/kanban/board/state-update', handler: _lazy_jLYBIl, lazy: true, middleware: false, method: "put" },
  { route: '/api/apps/kanban', handler: _lazy_mrw4gS, lazy: true, middleware: false, method: "get" },
  { route: '/api/apps/kanban/item/:id', handler: _lazy_LBFthB, lazy: true, middleware: false, method: "delete" },
  { route: '/api/apps/kanban/item/add', handler: _lazy_aXLXrn, lazy: true, middleware: false, method: "post" },
  { route: '/api/apps/kanban/item/state-update', handler: _lazy_OHINfi, lazy: true, middleware: false, method: "put" },
  { route: '/api/apps/kanban/item/update', handler: _lazy_vo6S1Q, lazy: true, middleware: false, method: "put" },
  { route: '/api/apps/logistics/vehicles', handler: _lazy_z0anJq, lazy: true, middleware: false, method: undefined },
  { route: '/api/apps/permissions', handler: _lazy_kATGQP, lazy: true, middleware: false, method: "get" },
  { route: '/api/apps/users/:id', handler: _lazy_IbXmnN, lazy: true, middleware: false, method: "delete" },
  { route: '/api/apps/users/:id', handler: _lazy_K474JG, lazy: true, middleware: false, method: "get" },
  { route: '/api/apps/users', handler: _lazy_ov2ZFu, lazy: true, middleware: false, method: "get" },
  { route: '/api/apps/users', handler: _lazy_GXX4LO, lazy: true, middleware: false, method: "post" },
  { route: '/api/auth/**', handler: _lazy_5xPTtA, lazy: true, middleware: false, method: undefined },
  { route: '/api/pages/datatable', handler: _lazy_rz4X9a, lazy: true, middleware: false, method: "get" },
  { route: '/api/pages/faq', handler: _lazy_khpwWV, lazy: true, middleware: false, method: "get" },
  { route: '/api/pages/help-center/article', handler: _lazy_oeHdbm, lazy: true, middleware: false, method: "get" },
  { route: '/api/pages/help-center', handler: _lazy_eNxXsa, lazy: true, middleware: false, method: "get" },
  { route: '/api/pages/profile/header', handler: _lazy_wzYTug, lazy: true, middleware: false, method: "get" },
  { route: '/api/pages/profile', handler: _lazy_IbOeYc, lazy: true, middleware: false, method: "get" },
  { route: '/**', handler: _lazy_gbM3Ht, lazy: true, middleware: false, method: undefined }
];

function createNitroApp() {
  const config = useRuntimeConfig();
  const hooks = createHooks();
  const captureError = (error, context = {}) => {
    const promise = hooks.callHookParallel("error", error, context).catch((_err) => {
      console.error("Error while capturing another error", _err);
    });
    if (context.event && isEvent(context.event)) {
      const errors = context.event.context.nitro?.errors;
      if (errors) {
        errors.push({ error, context });
      }
      if (context.event.waitUntil) {
        context.event.waitUntil(promise);
      }
    }
  };
  const h3App = createApp({
    debug: destr(false),
    onError: (error, event) => {
      captureError(error, { event, tags: ["request"] });
      return errorHandler(error, event);
    },
    onRequest: async (event) => {
      await nitroApp.hooks.callHook("request", event).catch((error) => {
        captureError(error, { event, tags: ["request"] });
      });
    },
    onBeforeResponse: async (event, response) => {
      await nitroApp.hooks.callHook("beforeResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    },
    onAfterResponse: async (event, response) => {
      await nitroApp.hooks.callHook("afterResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    }
  });
  const router = createRouter$1({
    preemptive: true
  });
  const localCall = createCall(toNodeListener(h3App));
  const _localFetch = createFetch(localCall, globalThis.fetch);
  const localFetch = (input, init) => _localFetch(input, init).then(
    (response) => normalizeFetchResponse(response)
  );
  const $fetch = createFetch$1({
    fetch: localFetch,
    Headers: Headers$1,
    defaults: { baseURL: config.app.baseURL }
  });
  globalThis.$fetch = $fetch;
  h3App.use(createRouteRulesHandler({ localFetch }));
  h3App.use(
    eventHandler((event) => {
      event.context.nitro = event.context.nitro || { errors: [] };
      const envContext = event.node.req?.__unenv__;
      if (envContext) {
        Object.assign(event.context, envContext);
      }
      event.fetch = (req, init) => fetchWithEvent(event, req, init, { fetch: localFetch });
      event.$fetch = (req, init) => fetchWithEvent(event, req, init, {
        fetch: $fetch
      });
      event.waitUntil = (promise) => {
        if (!event.context.nitro._waitUntilPromises) {
          event.context.nitro._waitUntilPromises = [];
        }
        event.context.nitro._waitUntilPromises.push(promise);
        if (envContext?.waitUntil) {
          envContext.waitUntil(promise);
        }
      };
      event.captureError = (error, context) => {
        captureError(error, { event, ...context });
      };
    })
  );
  for (const h of handlers) {
    let handler = h.lazy ? lazyEventHandler(h.handler) : h.handler;
    if (h.middleware || !h.route) {
      const middlewareBase = (config.app.baseURL + (h.route || "/")).replace(
        /\/+/g,
        "/"
      );
      h3App.use(middlewareBase, handler);
    } else {
      const routeRules = getRouteRulesForPath(
        h.route.replace(/:\w+|\*\*/g, "_")
      );
      if (routeRules.cache) {
        handler = cachedEventHandler(handler, {
          group: "nitro/routes",
          ...routeRules.cache
        });
      }
      router.use(h.route, handler, h.method);
    }
  }
  h3App.use(config.app.baseURL, router.handler);
  const app = {
    hooks,
    h3App,
    router,
    localCall,
    localFetch,
    captureError
  };
  for (const plugin of plugins) {
    try {
      plugin(app);
    } catch (err) {
      captureError(err, { tags: ["plugin"] });
      throw err;
    }
  }
  return app;
}
const nitroApp = createNitroApp();
const useNitroApp = () => nitroApp;

const localFetch = nitroApp.localFetch;
const closePrerenderer = () => nitroApp.hooks.callHook("close");
trapUnhandledNodeErrors();

const _____ = /*#__PURE__*/Object.freeze({
  __proto__: null
});

export { useNitroApp as a, useStorage as b, closePrerenderer as c, defineCachedEventHandler as d, getRouteRules as g, localFetch as l, useRuntimeConfig as u };
