import { defineEventHandler, setResponseStatus } from 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/h3/dist/index.mjs';
import { d as db } from '../../../../_/index10.mjs';
import '../../../../_/getPublicUrl.mjs';
import 'file://C:/laragon/www/product-nuxt/klinik-rsi/admin-panel/node_modules/@antfu/utils/dist/index.mjs';

const header_get = defineEventHandler(async (event) => {
  setResponseStatus(event, 200);
  return db.data.profileHeader;
});

export { header_get as default };
