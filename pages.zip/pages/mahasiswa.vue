<script lang="ts" setup></script>

<template>
  <div>File ini ada karena routing menu halaman ini dari api belum dihapus</div>
</template>

<style></style>
